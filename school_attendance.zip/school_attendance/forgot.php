<?php
/* نسيت كلمة المرور: يُسجَّل الطلب ويظهر للمدير ليعيّن كلمة جديدة */
require_once __DIR__ . '/includes/auth_layout.php';

$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim($_POST['email'] ?? '');
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        db()->prepare("UPDATE users SET reset_requested = 1 WHERE email = ? AND role = 'teacher'")->execute([$email]);
    }
    $sent = true; // نفس الرسالة دائما حتى لا نكشف وجود الحساب
}

auth_start('استعادة كلمة المرور');
?>
      <h1 class="login-title">نسيت كلمة المرور؟</h1>
      <p class="login-sub">أدخل بريدك وسيعيّن لك المدير كلمة مرور جديدة</p>
      <?php if ($sent): ?>
        <div class="alert alert-success">إن كان البريد مسجلا فقد وصل طلبك إلى الإدارة. راجع المدير للحصول على كلمة المرور الجديدة.</div>
        <a href="<?= url('index.php') ?>" class="btn-primary">العودة لتسجيل الدخول</a>
      <?php else: ?>
        <form method="post" class="login-form">
          <?= csrf_field() ?>
          <label class="field"><span class="field-label">البريد الإلكتروني</span>
            <span class="input-wrap"><?= icon('mail') ?><input type="email" name="email" dir="ltr" required placeholder="name@school.dz"></span></label>
          <button type="submit" class="btn-primary">إرسال الطلب</button>
          <div class="divider"><span>أو</span></div>
          <a href="<?= url('index.php') ?>" class="btn-ghost">العودة لتسجيل الدخول</a>
        </form>
      <?php endif; ?>
<?php auth_end();
