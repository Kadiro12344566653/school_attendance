<?php
/* ------------------------------------------------------------------
 *  إعدادات التطبيق — عدّلها حسب جهازك
 * ------------------------------------------------------------------ */

// قاعدة البيانات (الإعدادات الافتراضية لـ XAMPP)
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'school_attendance');
define('DB_USER', 'root');
define('DB_PASS', '');

// اسم المجلد داخل htdocs (بدون / في النهاية). إن وضعت المشروع في جذر الخادم اكتب ''.
define('BASE_URL', '/school_attendance');

define('APP_NAME',    'دفتر الغيابات');
define('SCHOOL_NAME', 'متوسطة الشهيد بدراني بوعمامة – بوعلام');

date_default_timezone_set('Africa/Algiers');

// أيام الدراسة: 0=الأحد ... 4=الخميس  (date('w'))
define('SCHOOL_DAYS', [0, 1, 2, 3, 4]);

// تقييد توقيع الأستاذ بوقت الحصة؟ (false = يمكنه التوقيع في أي وقت من نفس اليوم)
define('STRICT_TIME_WINDOW', false);
define('SIGN_EARLY_MINUTES', 10);   // يُسمح بالتوقيع قبل بداية الحصة بـ 10 دقائق
define('SIGN_LATE_MINUTES', 30);    // وبعد نهايتها بـ 30 دقيقة

// في ورقة الطباعة: إظهار اسم المادة فقط بعد توقيع الأستاذ؟
// false = تظهر المادة من جدول التوقيت دائما (مثل الورقة الأصلية) ويظهر التوقيع تحتها عند الحضور
define('PRINT_SUBJECT_ONLY_IF_SIGNED', false);

// الحد الأقصى لحجم صورة التوقيع (بايت)
define('MAX_SIGNATURE_BYTES', 500 * 1024);

// إظهار تفاصيل الأخطاء أثناء التطوير فقط
define('APP_DEBUG', true);
