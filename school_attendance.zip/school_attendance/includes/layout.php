<?php
require_once __DIR__ . '/auth.php';

/** أيقونات SVG مدمجة (تعمل دون إنترنت داخل WebView) */
function icon(string $name): string
{
    $p = [
        'home'     => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
        'users'    => '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><path d="M16 4.8a3 3 0 0 1 0 6"/><path d="M18 14.6c1.9.6 3 2.3 3 4.9"/>',
        'calendar' => '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
        'student'  => '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
        'print'    => '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
        'logout'   => '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 8l-4 4 4 4M6 12h10"/>',
        'pen'      => '<path d="M4 20l4-1 11-11-3-3L5 16z"/><path d="M14 6l3 3"/>',
        'check'    => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        'clock'    => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
        'trash'    => '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
        'upload'   => '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v4h16v-4"/>',
        'back'     => '<path d="M9 5l7 7-7 7"/>',
        'mail'     => '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 6.5 12 13l8.5-6.5"/>',
        'lock'     => '<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
        'eye'      => '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'eye-off'  => '<path d="M3 3l18 18"/><path d="M10.6 5.6A10.6 10.6 0 0 1 12 5.5C18.4 5.5 22 12 22 12a17 17 0 0 1-3.2 4"/><path d="M6.6 6.7C3.6 8.6 2 12 2 12s3.6 6.5 10 6.5c1.6 0 3-.4 4.3-1"/><path d="M9.9 10a3 3 0 0 0 4.1 4.1"/>',
        'user'     => '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20.5c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/>',
        'phone'    => '<path d="M5 4h3.5l1.5 4-2 1.5a11 11 0 0 0 6.5 6.5l1.5-2 4 1.5V19a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        'book'     => '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 0 6.5 23H20v-5"/>',
    ][$name] ?? '';
    return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

function page_start(string $title, string $active = '', ?string $back = null): void
{
    $u = current_user();
    ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0b4b8a">
<meta name="csrf" content="<?= csrf_token() ?>">
<title><?= e($title) ?> – <?= e(APP_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body class="app-body">
<header class="appbar">
  <?php if ($back): ?>
    <a class="appbar-btn" href="<?= e(url($back)) ?>" aria-label="رجوع"><?= icon('back') ?></a>
  <?php endif; ?>
  <div class="appbar-title">
    <h1><?= e($title) ?></h1>
    <?php if ($u): ?><span><?= e($u['full_name']) ?></span><?php endif; ?>
  </div>
  <?php if ($u): ?>
    <a class="appbar-btn" href="<?= url('logout.php') ?>" aria-label="خروج"><?= icon('logout') ?></a>
  <?php endif; ?>
</header>
<div class="toasts">
<?php foreach (take_flashes() as $f): ?>
  <div class="toast toast-<?= e($f['type']) ?>" role="status"><?= e($f['msg']) ?></div>
<?php endforeach; ?>
</div>
<main class="page" data-active="<?= e($active) ?>">
<?php
}

function page_end(array $scripts = []): void
{
    $u = current_user();
    echo "</main>\n";
    if ($u && $u['role'] === 'admin') {
        $items = [
            'dash'     => ['admin/index.php',    'home',     'المتابعة'],
            'teachers' => ['admin/teachers.php', 'users',    'الأساتذة'],
            'schedule' => ['admin/schedule.php', 'calendar', 'التوقيت'],
            'students' => ['admin/students.php', 'student',  'التلاميذ'],
            'print'    => ['admin/print.php',    'print',    'الطباعة'],
        ];
    } elseif ($u) {
        $items = [
            'today' => ['teacher/index.php',        'clock',    'حصص اليوم'],
            'week'  => ['teacher/index.php#week',   'calendar', 'جدولي'],
        ];
    } else {
        $items = [];
    }
    if ($items) {
        echo '<nav class="bottomnav">';
        foreach ($items as $key => [$href, $ic, $label]) {
            echo '<a href="' . e(url($href)) . '" data-key="' . $key . '">' . icon($ic) . '<span>' . e($label) . '</span></a>';
        }
        echo '</nav>';
    }
    echo '<script src="' . url('assets/js/app.js') . '"></script>';
    foreach ($scripts as $s) echo '<script src="' . url($s) . '"></script>';
    echo "\n</body>\n</html>";
}
