<?php
require_once __DIR__ . '/../config/config.php';

function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function is_ajax(): bool
{
    return (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
        || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
}

function json_out(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ------------------------- رسائل مؤقتة ------------------------- */
function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/* ------------------------- التواريخ والتسميات ------------------------- */
const AR_DAYS   = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const AR_LEVELS = [1 => 'الأولى', 2 => 'الثانية', 3 => 'الثالثة', 4 => 'الرابعة'];
const PERIODS   = ['morning' => 'الفترة الصباحية', 'evening' => 'الفترة المسائية'];

function valid_date(?string $d): string
{
    if ($d && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
        [$y, $m, $day] = array_map('intval', explode('-', $d));
        if (checkdate($m, $day, $y)) return $d;
    }
    return date('Y-m-d');
}

function day_of_week(string $date): int
{
    return (int)date('w', strtotime($date));
}

function is_school_day(string $date): bool
{
    return in_array(day_of_week($date), SCHOOL_DAYS, true);
}

/** آخر يوم دراسة قبل التاريخ المعطى (مثلا: الخميس قبل الأحد) */
function previous_school_day(string $date): string
{
    $t = strtotime($date);
    for ($i = 1; $i <= 7; $i++) {
        $p = strtotime("-$i day", $t);
        if (in_array((int)date('w', $p), SCHOOL_DAYS, true)) return date('Y-m-d', $p);
    }
    return date('Y-m-d', strtotime('-1 day', $t));
}

function ar_date(string $date): string
{
    return AR_DAYS[day_of_week($date)] . ' ' . date('d/m/Y', strtotime($date));
}

function hm(string $time): string
{
    return substr($time, 0, 5);
}

/** صيغة الورقة الأصلية: 08سا ، 09سا و55د */
function sheet_time(string $t): string
{
    [$h, $m] = explode(':', $t);
    return $m === '00' ? "{$h}سا" : "{$h}سا و{$m}د";
}

function class_full_label(int $level, int $group): string
{
    return 'السنة ' . (AR_LEVELS[$level] ?? $level) . ' – الفوج ' . $group;
}

/** يحوّل "أولى/ثانية/..." أو رقما إلى 1..4 */
function parse_level($v): ?int
{
    $v = trim((string)$v);
    if ($v === '') return null;
    if (ctype_digit($v)) return (int)$v;
    $map = ['أولى' => 1, 'اولى' => 1, 'ثانية' => 2, 'ثالثة' => 3, 'رابعة' => 4];
    foreach ($map as $k => $n) {
        if (mb_strpos($v, $k) !== false) return $n;
    }
    if (preg_match('/(\d)/', $v, $m)) return (int)$m[1];
    return null;
}

/** جلب القسم حسب المستوى والفوج، أو إنشاؤه إن لم يوجد */
function class_id_for(int $level, int $group): int
{
    $st = db()->prepare('SELECT id FROM classes WHERE level = ? AND group_no = ?');
    $st->execute([$level, $group]);
    $id = $st->fetchColumn();
    if ($id) return (int)$id;
    db()->prepare('INSERT INTO classes (level, group_no, label) VALUES (?, ?, ?)')
        ->execute([$level, $group, $level . 'م' . $group]);
    return (int)db()->lastInsertId();
}

function all_classes(): array
{
    return db()->query('SELECT * FROM classes ORDER BY level, group_no')->fetchAll();
}

function all_session_times(): array
{
    return db()->query("SELECT * FROM session_times ORDER BY FIELD(period,'morning','evening'), session_no")->fetchAll();
}

/** نص خانة المادة: مادة واحدة بالاسم الكامل، مادتان بالاختصار "عر / ريا" */
function subjects_cell_text(array $entries): string
{
    if (!$entries) return '';
    if (count($entries) === 1) return $entries[0]['subject_name'];
    return implode(' / ', array_map(fn($x) => $x['short_name'], $entries));
}

/** هل الوقت الحالي داخل نافذة التوقيع المسموح بها للحصة؟ */
function sign_window_ok(string $start, string $end): bool
{
    if (!STRICT_TIME_WINDOW) return true;
    $now  = time();
    $from = strtotime(date('Y-m-d') . ' ' . $start) - SIGN_EARLY_MINUTES * 60;
    $to   = strtotime(date('Y-m-d') . ' ' . $end) + SIGN_LATE_MINUTES * 60;
    return $now >= $from && $now <= $to;
}

/** حصص أستاذ في يوم معيّن مع حالة التوقيع وعدد الغيابات لتاريخ محدد */
function teacher_sessions(int $teacherId, string $date): array
{
    $st = db()->prepare(
        "SELECT cs.id, cs.class_id, c.label, c.level, c.group_no,
                s.name AS subject_name, s.short_name,
                t.period, t.session_no, t.start_time, t.end_time,
                ta.signed_at, ta.absences_submitted_at,
                (SELECT COUNT(*) FROM student_absences sa
                  WHERE sa.schedule_id = cs.id AND sa.absence_date = :d1) AS abs_count
           FROM classes_schedule cs
           JOIN classes c        ON c.id = cs.class_id
           JOIN subjects s       ON s.id = cs.subject_id
           JOIN session_times t  ON t.id = cs.session_time_id
      LEFT JOIN teacher_attendance ta ON ta.schedule_id = cs.id AND ta.att_date = :d2
          WHERE cs.teacher_id = :tid AND cs.day_of_week = :dow AND cs.is_active = 1
       ORDER BY FIELD(t.period,'morning','evening'), t.session_no"
    );
    $st->execute([':d1' => $date, ':d2' => $date, ':tid' => $teacherId, ':dow' => day_of_week($date)]);
    return $st->fetchAll();
}
