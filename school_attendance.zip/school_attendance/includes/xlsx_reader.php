<?php
/**
 * قارئ خفيف لملفات Excel (.xlsx) دون مكتبات خارجية.
 * يحتاج امتداد ZipArchive (extension=zip في php.ini — مفعّل افتراضيا في XAMPP 8).
 */
function xlsx_sheet_names(string $path): array
{
    return array_keys(xlsx_sheet_map($path));
}

/** اسم الورقة => مسار ملف XML داخل الأرشيف */
function xlsx_sheet_map(string $path): array
{
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) throw new RuntimeException('تعذر فتح ملف Excel.');
    $wb   = simplexml_load_string($zip->getFromName('xl/workbook.xml'));
    $rels = simplexml_load_string($zip->getFromName('xl/_rels/workbook.xml.rels'));
    $zip->close();
    if (!$wb || !$rels) throw new RuntimeException('ملف Excel غير صالح.');

    $targets = [];
    foreach ($rels->Relationship as $r) {
        $t = (string)$r['Target'];
        $t = ltrim($t, '/');
        if (!str_starts_with($t, 'xl/')) $t = 'xl/' . $t;
        $targets[(string)$r['Id']] = $t;
    }
    $map = [];
    $ns  = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    foreach ($wb->sheets->sheet as $s) {
        $rid = (string)$s->attributes($ns)['id'];
        if (isset($targets[$rid])) $map[(string)$s['name']] = $targets[$rid];
    }
    return $map;
}

/** يعيد مصفوفة صفوف (كل صف مصفوفة قيم نصية مرتبة حسب الأعمدة) */
function xlsx_read_rows(string $path, ?string $sheet = null): array
{
    $map = xlsx_sheet_map($path);
    if (!$map) throw new RuntimeException('لا توجد أوراق في الملف.');
    $file = ($sheet !== null && isset($map[$sheet])) ? $map[$sheet] : reset($map);

    $zip = new ZipArchive();
    $zip->open($path);
    $shared = [];
    if (($ss = $zip->getFromName('xl/sharedStrings.xml')) !== false) {
        $sx = simplexml_load_string($ss);
        foreach ($sx->si as $si) {
            if (isset($si->t)) {
                $shared[] = (string)$si->t;
            } else {
                $txt = '';
                foreach ($si->r as $r) $txt .= (string)$r->t;
                $shared[] = $txt;
            }
        }
    }
    $xml = $zip->getFromName($file);
    $zip->close();
    if ($xml === false) throw new RuntimeException('تعذر قراءة الورقة.');

    $sheetXml = simplexml_load_string($xml);
    $rows = [];
    foreach ($sheetXml->sheetData->row as $row) {
        $vals = [];
        foreach ($row->c as $c) {
            $ref  = (string)$c['r'];
            $col  = xlsx_col_index(preg_replace('/\d+/', '', $ref));
            $type = (string)$c['t'];
            if ($type === 's') {
                $v = $shared[(int)$c->v] ?? '';
            } elseif ($type === 'inlineStr') {
                $v = (string)$c->is->t;
            } else {
                $v = (string)$c->v;
            }
            $vals[$col] = trim($v);
        }
        if (!$vals) continue;
        $max = max(array_keys($vals));
        $line = [];
        for ($i = 0; $i <= $max; $i++) $line[] = $vals[$i] ?? '';
        $rows[] = $line;
    }
    return $rows;
}

function xlsx_col_index(string $letters): int
{
    $n = 0;
    foreach (str_split(strtoupper($letters)) as $ch) $n = $n * 26 + (ord($ch) - 64);
    return $n - 1;
}

/** تحويل رقم تاريخ Excel أو نص إلى Y-m-d */
function excel_date($v): ?string
{
    $v = trim((string)$v);
    if ($v === '') return null;
    if (is_numeric($v) && (float)$v > 1000 && (float)$v < 80000) {
        return gmdate('Y-m-d', (int)round(((float)$v - 25569) * 86400));
    }
    $v = substr($v, 0, 10);
    if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $v, $m)) return sprintf('%04d-%02d-%02d', $m[1], $m[2], $m[3]);
    if (preg_match('~^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$~', $v, $m)) return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    return null;
}

/** قراءة CSV مع اكتشاف الفاصل والترميز */
function csv_read_rows(string $path): array
{
    $raw = file_get_contents($path);
    if ($raw === false) throw new RuntimeException('تعذر قراءة الملف.');
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
    if (!mb_check_encoding($raw, 'UTF-8')) {
        $conv = @iconv('Windows-1256', 'UTF-8//IGNORE', $raw);
        if ($conv !== false) $raw = $conv;
    }
    $first = strtok($raw, "\n");
    $delims = [',' => substr_count($first, ','), ';' => substr_count($first, ';'), "\t" => substr_count($first, "\t")];
    arsort($delims);
    $d = array_key_first($delims);

    $rows = [];
    $fh = fopen('php://memory', 'r+');
    fwrite($fh, $raw);
    rewind($fh);
    while (($r = fgetcsv($fh, 0, $d, '"', '\\')) !== false) {
        if ($r === [null]) continue;
        $rows[] = array_map(fn($x) => trim((string)$x), $r);
    }
    fclose($fh);
    return $rows;
}
