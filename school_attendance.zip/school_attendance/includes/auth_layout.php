<?php
require_once __DIR__ . '/layout.php';

/** غلاف صفحات الدخول/التسجيل: خلفية منقطة + بطاقة مكدسة */
function auth_start(string $title): void
{
    ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#e3effa">
<title><?= e($title) ?> – <?= e(APP_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/login.css') ?>">
</head>
<body class="login-body">
<main class="login-wrap">
  <div class="brand">
    <div class="brand-mark" aria-hidden="true"><?= icon('book') ?></div>
    <p class="brand-name"><?= e(APP_NAME) ?></p>
    <p class="brand-school"><?= e(SCHOOL_NAME) ?></p>
  </div>
  <div class="card-stack">
    <div class="stack-layer stack-layer--back" aria-hidden="true"></div>
    <div class="stack-layer stack-layer--mid" aria-hidden="true"></div>
    <section class="login-card">
<?php
}

function auth_end(): void
{
    ?>
    </section>
  </div>
</main>
<script src="<?= url('assets/js/login.js') ?>"></script>
</body>
</html>
<?php
}
