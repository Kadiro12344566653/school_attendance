<?php
require_once __DIR__ . '/../config/config.php';

/** اتصال PDO واحد مشترك */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            $pdo->exec("SET time_zone = '" . date('P') . "'");
        } catch (PDOException $e) {
            http_response_code(500);
            $msg = APP_DEBUG ? $e->getMessage() : 'تعذر الاتصال بقاعدة البيانات.';
            exit('<p dir="rtl" style="font-family:sans-serif;padding:20px">خطأ في قاعدة البيانات: ' . htmlspecialchars($msg) . '</p>');
        }
    }
    return $pdo;
}
