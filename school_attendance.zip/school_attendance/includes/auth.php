<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    session_name('SCHOOLSESS');
    session_start();
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'        => (int)$user['id'],
        'full_name' => $user['full_name'],
        'email'     => $user['email'],
        'role'      => $user['role'],
    ];
    db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** يمنع الدخول لغير المسجلين أو لغير الدور المطلوب */
function require_role(string $role): array
{
    $u = current_user();
    if (!$u) {
        if (is_ajax()) json_out(['ok' => false, 'error' => 'انتهت الجلسة، أعد تسجيل الدخول.'], 401);
        redirect('index.php');
    }
    if ($u['role'] !== $role) {
        if (is_ajax()) json_out(['ok' => false, 'error' => 'غير مسموح.'], 403);
        redirect(home_for_role($u['role']));
    }
    return $u;
}

function home_for_role(string $role): string
{
    return $role === 'admin' ? 'admin/index.php' : 'teacher/index.php';
}

/* ------------------------- CSRF ------------------------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verify_csrf(): void
{
    $sent = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        if (is_ajax()) json_out(['ok' => false, 'error' => 'رمز الحماية غير صالح، حدّث الصفحة.'], 419);
        http_response_code(419);
        exit('رمز الحماية غير صالح. ارجع وحدّث الصفحة.');
    }
}
