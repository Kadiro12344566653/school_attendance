<?php
/* طلب إنشاء حساب أستاذ — يبقى "في الانتظار" حتى يفعّله المدير */
require_once __DIR__ . '/includes/auth_layout.php';

if ($u = current_user()) redirect(home_for_role($u['role']));

$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => ''];
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $old = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'email'     => trim($_POST['email'] ?? ''),
        'phone'     => trim($_POST['phone'] ?? ''),
    ];
    $pass  = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if (mb_strlen($old['full_name']) < 3)                    $errors[] = 'أدخل الاسم الكامل.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL))   $errors[] = 'البريد الإلكتروني غير صحيح.';
    if (strlen($pass) < 6)                                   $errors[] = 'كلمة المرور 6 أحرف على الأقل.';
    if ($pass !== $pass2)                                    $errors[] = 'كلمتا المرور غير متطابقتين.';
    if (empty($_POST['terms']))                              $errors[] = 'يجب الموافقة على الشروط وسياسة الخصوصية.';

    if (!$errors) {
        $st = db()->prepare('SELECT 1 FROM users WHERE email = ?');
        $st->execute([$old['email']]);
        if ($st->fetchColumn()) $errors[] = 'هذا البريد مسجل مسبقا.';
    }
    if (!$errors) {
        db()->prepare("INSERT INTO users (full_name, email, password_hash, role, phone, status) VALUES (?, ?, ?, 'teacher', ?, 'pending')")
            ->execute([$old['full_name'], $old['email'], password_hash($pass, PASSWORD_DEFAULT), $old['phone'] ?: null]);
        $done = true;
    }
}

auth_start('إنشاء حساب');
?>
      <h1 class="login-title">إنشاء حساب أستاذ</h1>
      <p class="login-sub">يُفعَّل الحساب بعد موافقة المدير وإسناد المواد</p>

      <?php if ($done): ?>
        <div class="alert alert-success">تم إرسال طلبك. ستتمكن من الدخول بعد تفعيل المدير لحسابك.</div>
        <a href="<?= url('index.php') ?>" class="btn-primary">العودة لتسجيل الدخول</a>
      <?php else: ?>
        <?php foreach ($errors as $er): ?><div class="alert"><?= e($er) ?></div><?php endforeach; ?>
        <form method="post" class="login-form">
          <?= csrf_field() ?>
          <label class="field"><span class="field-label">الاسم الكامل</span>
            <span class="input-wrap"><?= icon('user') ?><input name="full_name" value="<?= e($old['full_name']) ?>" required placeholder="مثال: هشام بدارني"></span></label>
          <label class="field"><span class="field-label">البريد الإلكتروني</span>
            <span class="input-wrap"><?= icon('mail') ?><input type="email" name="email" dir="ltr" value="<?= e($old['email']) ?>" required placeholder="name@school.dz"></span></label>
          <label class="field"><span class="field-label">الهاتف (اختياري)</span>
            <span class="input-wrap"><?= icon('phone') ?><input type="tel" name="phone" dir="ltr" value="<?= e($old['phone']) ?>" placeholder="06xxxxxxxx"></span></label>
          <label class="field"><span class="field-label">كلمة المرور</span>
            <span class="input-wrap"><?= icon('lock') ?><input type="password" name="password" id="rp1" dir="ltr" required minlength="6">
            <button type="button" class="eye-btn" data-toggle-password="rp1" aria-label="إظهار كلمة المرور" aria-pressed="false"><span class="eye-show"><?= icon('eye') ?></span><span class="eye-hide"><?= icon('eye-off') ?></span></button></span></label>
          <label class="field"><span class="field-label">تأكيد كلمة المرور</span>
            <span class="input-wrap"><?= icon('lock') ?><input type="password" name="password2" dir="ltr" required minlength="6"></span></label>
          <label class="check">
            <input type="checkbox" name="terms" value="1" required>
            <span class="check-box" aria-hidden="true"><?= icon('check') ?></span>
            <span>أوافق على <a href="<?= url('terms.php') ?>" class="link">الشروط</a> و<a href="<?= url('terms.php#privacy') ?>" class="link">سياسة الخصوصية</a></span>
          </label>
          <button type="submit" class="btn-primary">إرسال الطلب</button>
          <div class="divider"><span>أو</span></div>
          <a href="<?= url('index.php') ?>" class="btn-ghost">لدي حساب، تسجيل الدخول</a>
        </form>
      <?php endif; ?>
<?php auth_end();
