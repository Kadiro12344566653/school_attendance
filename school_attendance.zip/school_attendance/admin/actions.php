<?php
/* كل أفعال المدير (POST ثم إعادة توجيه) */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/xlsx_reader.php';

$me = require_role('admin');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('admin/index.php');
verify_csrf();

$action = $_POST['action'] ?? '';
$pdo    = db();

/** العودة لصفحة داخل لوحة المدير فقط (لا إعادة توجيه خارجية) */
function back(string $default): void
{
    $b = $_POST['back'] ?? '';
    redirect(preg_match('~^admin/[a-z_]+\.php(\?[\w=&%-]*)?$~', $b) ? $b : $default);
}

function fail(string $msg, string $to): void
{
    flash('error', $msg);
    redirect($to);
}

/** حفظ مواد الأستاذ */
function save_teacher_subjects(int $teacherId, array $subjectIds): void
{
    db()->prepare('DELETE FROM teacher_subjects WHERE teacher_id = ?')->execute([$teacherId]);
    $ins = db()->prepare('INSERT IGNORE INTO teacher_subjects (teacher_id, subject_id) SELECT ?, id FROM subjects WHERE id = ?');
    foreach (array_unique(array_map('intval', $subjectIds)) as $sid) $ins->execute([$teacherId, $sid]);
}

switch ($action) {

/* ======================= الأساتذة ======================= */
case 'add_teacher':
case 'update_teacher':
    $id    = (int)($_POST['id'] ?? 0);
    $name  = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pass  = (string)($_POST['password'] ?? '');
    $subs  = (array)($_POST['subjects'] ?? []);
    $to    = 'admin/teachers.php' . ($id ? "?edit=$id" : '');

    if (mb_strlen($name) < 3) fail('أدخل اسم الأستاذ.', $to);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('البريد الإلكتروني غير صحيح.', $to);
    if (($action === 'add_teacher' || $pass !== '') && strlen($pass) < 6) fail('كلمة المرور 6 أحرف على الأقل.', $to);

    $st = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id <> ?');
    $st->execute([$email, $id]);
    if ($st->fetchColumn()) fail('هذا البريد مستعمل لحساب آخر.', $to);

    $pdo->beginTransaction();
    if ($action === 'add_teacher') {
        $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role, phone, status) VALUES (?, ?, ?, 'teacher', ?, 'active')")
            ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), $phone ?: null]);
        $id = (int)$pdo->lastInsertId();
        $msg = "تمت إضافة الأستاذ $name.";
    } else {
        $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ? AND role = 'teacher'")
            ->execute([$name, $email, $phone ?: null, $id]);
        if ($pass !== '') {
            $pdo->prepare('UPDATE users SET password_hash = ?, reset_requested = 0 WHERE id = ?')
                ->execute([password_hash($pass, PASSWORD_DEFAULT), $id]);
        }
        $msg = 'تم حفظ التعديلات.' . ($pass !== '' ? ' سلّم الأستاذ كلمة المرور الجديدة.' : '');
    }
    save_teacher_subjects($id, $subs);
    $pdo->commit();
    flash('success', $msg);
    redirect('admin/teachers.php');

case 'set_status':
    $status = in_array($_POST['status'] ?? '', ['active', 'disabled'], true) ? $_POST['status'] : 'disabled';
    $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'teacher'")->execute([$status, (int)$_POST['id']]);
    flash('success', $status === 'active' ? 'تم تفعيل الحساب.' : 'تم إيقاف الحساب.');
    redirect('admin/teachers.php');

case 'delete_teacher':
    $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'teacher'")->execute([(int)$_POST['id']]);
    flash('success', 'تم حذف الأستاذ.');
    redirect('admin/teachers.php');

case 'change_own_password':
    $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
    $st->execute([$me['id']]);
    if (!password_verify((string)($_POST['current'] ?? ''), (string)$st->fetchColumn())) fail('كلمة المرور الحالية غير صحيحة.', 'admin/teachers.php');
    if (strlen((string)($_POST['new'] ?? '')) < 8) fail('كلمة المرور الجديدة 8 أحرف على الأقل.', 'admin/teachers.php');
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($_POST['new'], PASSWORD_DEFAULT), $me['id']]);
    flash('success', 'تم تغيير كلمة المرور.');
    redirect('admin/teachers.php');

/* ======================= المواد ======================= */
case 'add_subject':
    $name  = trim($_POST['name'] ?? '');
    $short = trim($_POST['short_name'] ?? '');
    if ($name === '' || $short === '') fail('أدخل اسم المادة واختصارها.', 'admin/teachers.php');
    try {
        $pdo->prepare('INSERT INTO subjects (name, short_name) VALUES (?, ?)')->execute([$name, $short]);
        flash('success', "تمت إضافة مادة $name.");
    } catch (PDOException $e) {
        flash('error', 'هذه المادة موجودة.');
    }
    redirect('admin/teachers.php');

case 'delete_subject':
    try {
        $pdo->prepare('DELETE FROM subjects WHERE id = ?')->execute([(int)$_POST['id']]);
        flash('success', 'تم حذف المادة.');
    } catch (PDOException $e) {
        flash('error', 'لا يمكن حذف مادة مستعملة في جدول التوقيت.');
    }
    redirect('admin/teachers.php');

/* ======================= جدول التوقيت ======================= */
case 'add_schedule':
    $classId = (int)($_POST['class_id'] ?? 0);
    $day     = (int)($_POST['day_of_week'] ?? -1);
    $timeId  = (int)($_POST['session_time_id'] ?? 0);
    $tid     = (int)($_POST['teacher_id'] ?? 0);
    $subId   = (int)($_POST['subject_id'] ?? 0);
    $to      = "admin/schedule.php?class_id=$classId&day=$day";

    if (!in_array($day, SCHOOL_DAYS, true)) fail('اليوم غير صالح.', $to);

    // خانة القسم: أستاذان كحد أقصى (فوج مقسم)
    $st = $pdo->prepare('SELECT teacher_id FROM classes_schedule WHERE class_id = ? AND day_of_week = ? AND session_time_id = ? AND is_active = 1');
    $st->execute([$classId, $day, $timeId]);
    $inCell = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    if (in_array($tid, $inCell, true)) fail('هذا الأستاذ مسجل في نفس الخانة.', $to);
    if (count($inCell) >= 2) fail('الخانة ممتلئة: لا يمكن وضع أكثر من مادتين في خانة واحدة.', $to);

    // الأستاذ لا يكون في قسمين في نفس الوقت
    $st = $pdo->prepare(
        'SELECT c.label FROM classes_schedule cs JOIN classes c ON c.id = cs.class_id
          WHERE cs.teacher_id = ? AND cs.day_of_week = ? AND cs.session_time_id = ? AND cs.is_active = 1'
    );
    $st->execute([$tid, $day, $timeId]);
    if ($busy = $st->fetchColumn()) fail("الأستاذ لديه حصة في القسم $busy في نفس الوقت.", $to);

    // المادة يجب أن تكون من مواد الأستاذ (إن حُددت له مواد)
    $st = $pdo->prepare('SELECT subject_id FROM teacher_subjects WHERE teacher_id = ?');
    $st->execute([$tid]);
    $allowed = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    if ($allowed && !in_array($subId, $allowed, true)) fail('هذه المادة ليست من مواد الأستاذ. عدّل مواده أولا.', $to);
    if (!$allowed) {
        // إسناد المادة تلقائيا للأستاذ الذي لا مادة له
        $pdo->prepare('INSERT IGNORE INTO teacher_subjects (teacher_id, subject_id) VALUES (?, ?)')->execute([$tid, $subId]);
    }

    try {
        // إعادة تفعيل خانة مؤرشفة إن وُجدت
        $st = $pdo->prepare('SELECT id FROM classes_schedule WHERE class_id = ? AND day_of_week = ? AND session_time_id = ? AND teacher_id = ? AND is_active = 0');
        $st->execute([$classId, $day, $timeId, $tid]);
        if ($old = $st->fetchColumn()) {
            $pdo->prepare('UPDATE classes_schedule SET is_active = 1, subject_id = ? WHERE id = ?')->execute([$subId, $old]);
        } else {
            $pdo->prepare('INSERT INTO classes_schedule (class_id, day_of_week, session_time_id, teacher_id, subject_id) VALUES (?, ?, ?, ?, ?)')
                ->execute([$classId, $day, $timeId, $tid, $subId]);
        }
        flash('success', 'تمت إضافة الحصة.');
    } catch (PDOException $e) {
        flash('error', 'تعذرت الإضافة: تحقق من المعطيات.');
    }
    redirect($to);

case 'delete_schedule':
    $id = (int)$_POST['id'];
    $st = $pdo->prepare('SELECT class_id, day_of_week FROM classes_schedule WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    $st = $pdo->prepare('SELECT (SELECT COUNT(*) FROM teacher_attendance WHERE schedule_id = ?) + (SELECT COUNT(*) FROM student_absences WHERE schedule_id = ?)');
    $st->execute([$id, $id]);
    if ((int)$st->fetchColumn() > 0) {
        // لها توقيعات/غيابات سابقة: نؤرشفها حفاظا على السجلات
        $pdo->prepare('UPDATE classes_schedule SET is_active = 0 WHERE id = ?')->execute([$id]);
    } else {
        $pdo->prepare('DELETE FROM classes_schedule WHERE id = ?')->execute([$id]);
    }
    flash('success', 'تم حذف الحصة من الجدول.');
    redirect($row ? "admin/schedule.php?class_id={$row['class_id']}&day={$row['day_of_week']}" : 'admin/schedule.php');

/* ======================= التلاميذ ======================= */
case 'import_students':
    $f = $_FILES['file'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) fail('لم يُرفع أي ملف (أو تجاوز الحجم المسموح).', 'admin/students.php');
    if ($f['size'] > 5 * 1024 * 1024) fail('حجم الملف أكبر من 5 ميغابايت.', 'admin/students.php');
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['xlsx', 'csv'], true)) fail('الصيغ المقبولة: xlsx أو csv. (احفظ ملف xls القديم بصيغة xlsx)', 'admin/students.php');

    try {
        if ($ext === 'xlsx') {
            if (!class_exists('ZipArchive')) fail('فعّل extension=zip في php.ini ثم أعد تشغيل Apache.', 'admin/students.php');
            $sheet = trim($_POST['sheet'] ?? '');
            $rows  = xlsx_read_rows($f['tmp_name'], $sheet !== '' ? $sheet : null);
        } else {
            $rows = csv_read_rows($f['tmp_name']);
        }
    } catch (Throwable $e) {
        fail('تعذرت قراءة الملف: ' . $e->getMessage(), 'admin/students.php');
    }

    // البحث عن سطر العناوين وتحديد الأعمدة
    $cols = null; $start = 0;
    foreach (array_slice($rows, 0, 10) as $i => $r) {
        $map = [];
        foreach ($r as $ci => $h) {
            $h = trim($h);
            if ($h === '') continue;
            if (!isset($map['name'])     && mb_strpos($h, 'اسم') !== false)      $map['name'] = $ci;
            elseif (!isset($map['level'])  && (mb_strpos($h, 'مستوى') !== false || mb_strpos($h, 'السنة') !== false)) $map['level'] = $ci;
            elseif (!isset($map['group'])  && mb_strpos($h, 'فوج') !== false)    $map['group'] = $ci;
            elseif (!isset($map['nid'])    && mb_strpos($h, 'تعريف') !== false)  $map['nid'] = $ci;
            elseif (!isset($map['birth'])  && mb_strpos($h, 'ميلاد') !== false)  $map['birth'] = $ci;
            elseif (!isset($map['regime']) && mb_strpos($h, 'نظام') !== false)   $map['regime'] = $ci;
            elseif (!isset($map['reg'])    && mb_strpos($h, 'تسجيل') !== false)  $map['reg'] = $ci;
        }
        if (isset($map['name'], $map['level'], $map['group'])) { $cols = $map; $start = $i + 1; break; }
    }
    if (!$cols) fail('لم أجد أعمدة: اسم التلميذ / المستوى / رقم الفوج في سطر العناوين.', 'admin/students.php');

    $get = fn(array $r, string $k) => isset($cols[$k]) ? trim((string)($r[$cols[$k]] ?? '')) : '';
    $added = $updated = $skipped = 0;

    $pdo->beginTransaction();
    try {
        if (($_POST['mode'] ?? '') === 'replace') {
            // لا نحذف (حفاظا على سجل الغيابات)، بل نعطّل ثم نعيد تفعيل الموجود في الملف
            $pdo->exec('UPDATE students SET is_active = 0');
        }
        $upsert = $pdo->prepare(
            'INSERT INTO students (national_id, full_name, birth_date, class_id, regime, reg_number, is_active)
             VALUES (?, ?, ?, ?, ?, ?, 1)
             ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), birth_date = VALUES(birth_date),
                 class_id = VALUES(class_id), regime = VALUES(regime), reg_number = VALUES(reg_number), is_active = 1'
        );
        $findByName = $pdo->prepare('SELECT id FROM students WHERE full_name = ? AND class_id = ? LIMIT 1');
        $reactivate = $pdo->prepare('UPDATE students SET is_active = 1, birth_date = COALESCE(?, birth_date) WHERE id = ?');

        foreach (array_slice($rows, $start) as $r) {
            $name  = preg_replace('/\s+/u', ' ', $get($r, 'name'));
            $level = parse_level($get($r, 'level'));
            $group = (int)$get($r, 'group');
            if ($name === '' || !$level || $group < 1) { $skipped++; continue; }

            $classId = class_id_for($level, $group);
            $nid     = $get($r, 'nid');
            if ($nid !== '' && stripos($nid, 'e') !== false && is_numeric($nid)) $nid = sprintf('%.0f', (float)$nid);
            $nid     = preg_replace('/\D/', '', $nid);
            $birth   = excel_date($get($r, 'birth'));
            $regime  = $get($r, 'regime') ?: null;
            $reg     = $get($r, 'reg') ?: null;

            if ($nid !== '') {
                $upsert->execute([$nid, $name, $birth, $classId, $regime, $reg]);
                $upsert->rowCount() === 1 ? $added++ : $updated++;
            } else {
                $findByName->execute([$name, $classId]);
                if ($sid = $findByName->fetchColumn()) {
                    $reactivate->execute([$birth, $sid]);
                    $updated++;
                } else {
                    $upsert->execute([null, $name, $birth, $classId, $regime, $reg]);
                    $added++;
                }
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('فشل الاستيراد: ' . (APP_DEBUG ? $e->getMessage() : 'خطأ في البيانات.'), 'admin/students.php');
    }
    flash('success', "تم الاستيراد: $added جديد، $updated محدَّث" . ($skipped ? "، $skipped سطر متجاهل" : '') . '.');
    redirect('admin/students.php');

case 'add_student':
    $name = trim($_POST['full_name'] ?? '');
    $cid  = (int)($_POST['class_id'] ?? 0);
    $nid  = preg_replace('/\D/', '', $_POST['national_id'] ?? '');
    if ($name === '') fail('أدخل اسم التلميذ.', 'admin/students.php');
    try {
        $pdo->prepare('INSERT INTO students (national_id, full_name, class_id) VALUES (?, ?, ?)')->execute([$nid ?: null, $name, $cid]);
        flash('success', "تمت إضافة $name.");
    } catch (PDOException $e) {
        flash('error', 'رقم التعريف مستعمل لتلميذ آخر.');
    }
    redirect("admin/students.php?class_id=$cid");

case 'delete_student':
    // تعطيل بدل الحذف للحفاظ على سجل الغيابات
    $pdo->prepare('UPDATE students SET is_active = 0 WHERE id = ?')->execute([(int)$_POST['id']]);
    flash('success', 'تم حذف التلميذ من القائمة.');
    back('admin/students.php');

/* ======================= المتابعة ======================= */
case 'toggle_justify':
    $val = (int)($_POST['value'] ?? 0) ? 1 : 0;
    $pdo->prepare('UPDATE student_absences SET is_justified = ?, justified_by = ? WHERE student_id = ? AND absence_date = ?')
        ->execute([$val, $val ? $me['id'] : null, (int)$_POST['student_id'], valid_date($_POST['date'] ?? null)]);
    flash('success', $val ? 'تم شطب الاسم (قدّم رخصة الدخول).' : 'تم التراجع عن الشطب.');
    back('admin/index.php');

case 'reset_signature':
    $pdo->prepare('DELETE FROM teacher_attendance WHERE id = ?')->execute([(int)$_POST['att_id']]);
    flash('success', 'تم حذف التوقيع، يمكن للأستاذ التوقيع من جديد.');
    back('admin/index.php');

default:
    flash('error', 'إجراء غير معروف.');
    redirect('admin/index.php');
}
