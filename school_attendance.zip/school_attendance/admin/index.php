<?php
/* لوحة متابعة المدير: حضور الأساتذة + الغائبون ليوم معيّن */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('admin');

$date = valid_date($_GET['date'] ?? null);
$dow  = day_of_week($date);
$prev = previous_school_day($date);

// كل حصص اليوم مع حالة التوقيع
$st = db()->prepare(
    "SELECT cs.id, u.id AS teacher_id, u.full_name, c.label, s.name AS subject_name,
            t.period, t.session_no, t.start_time, t.end_time,
            ta.id AS att_id, ta.signed_at, ta.signature, ta.absences_submitted_at,
            (SELECT COUNT(*) FROM student_absences sa WHERE sa.schedule_id = cs.id AND sa.absence_date = :d1) AS abs_count
       FROM classes_schedule cs
       JOIN users u          ON u.id = cs.teacher_id
       JOIN classes c        ON c.id = cs.class_id
       JOIN subjects s       ON s.id = cs.subject_id
       JOIN session_times t  ON t.id = cs.session_time_id
  LEFT JOIN teacher_attendance ta ON ta.schedule_id = cs.id AND ta.att_date = :d2
      WHERE cs.day_of_week = :dow AND (cs.is_active = 1 OR ta.id IS NOT NULL)
   ORDER BY u.full_name, FIELD(t.period,'morning','evening'), t.session_no"
);
$st->execute([':d1' => $date, ':d2' => $date, ':dow' => $dow]);
$rows = $st->fetchAll();

$byTeacher = [];
foreach ($rows as $r) $byTeacher[$r['teacher_id']][] = $r;
$signedSessions  = count(array_filter($rows, fn($r) => $r['signed_at']));
$teachersPresent = count(array_filter($byTeacher, fn($list) => (bool)array_filter($list, fn($r) => $r['signed_at'])));

/** الغائبون في تاريخ معيّن مجمّعين حسب التلميذ */
function absentees(string $date): array
{
    $st = db()->prepare(
        "SELECT st.id, st.full_name, c.label, c.level, c.group_no,
                GROUP_CONCAT(CONCAT(IF(t.period='morning','ص','م'), t.session_no)
                             ORDER BY FIELD(t.period,'morning','evening'), t.session_no SEPARATOR ' ') AS sessions,
                MIN(sa.is_justified) AS justified
           FROM student_absences sa
           JOIN students st      ON st.id = sa.student_id
           JOIN classes c        ON c.id = st.class_id
           JOIN classes_schedule cs ON cs.id = sa.schedule_id
           JOIN session_times t  ON t.id = cs.session_time_id
          WHERE sa.absence_date = ?
       GROUP BY st.id, st.full_name, c.label, c.level, c.group_no
       ORDER BY c.level, c.group_no, st.full_name"
    );
    $st->execute([$date]);
    return $st->fetchAll();
}
$absToday = absentees($date);
$absPrev  = absentees($prev);

$pending = (int)db()->query("SELECT COUNT(*) FROM users WHERE status = 'pending'")->fetchColumn();
$resets  = (int)db()->query("SELECT COUNT(*) FROM users WHERE reset_requested = 1")->fetchColumn();

page_start('لوحة المتابعة', 'dash');
?>
<form class="card form" method="get">
  <div class="form-row">
    <label class="field"><span>اليوم</span>
      <input class="input" type="date" name="date" value="<?= e($date) ?>" data-autosubmit></label>
    <div class="field"><span>&nbsp;</span>
      <a class="btn btn-primary" href="<?= url('admin/print.php?date=' . $date) ?>"><?= icon('print') ?> ورقة الغيابات</a></div>
  </div>
  <p class="muted small" style="margin:0"><?= e(ar_date($date)) ?><?= is_school_day($date) ? '' : ' — عطلة' ?></p>
</form>

<?php if ($pending || $resets): ?>
  <a class="card" style="display:block;text-decoration:none;background:var(--warn-soft);color:var(--warn)" href="<?= url('admin/teachers.php') ?>">
    <?php if ($pending): ?><b><?= $pending ?></b> حساب جديد ينتظر التفعيل. <?php endif; ?>
    <?php if ($resets): ?><b><?= $resets ?></b> طلب استعادة كلمة مرور.<?php endif; ?>
  </a>
<?php endif; ?>

<div class="stats">
  <div class="stat"><b><?= $teachersPresent ?>/<?= count($byTeacher) ?></b><span>أساتذة حاضرون</span></div>
  <div class="stat"><b><?= $signedSessions ?>/<?= count($rows) ?></b><span>حصص موقّعة</span></div>
  <div class="stat alert"><b><?= count($absToday) ?></b><span>تلاميذ غائبون</span></div>
  <div class="stat"><b><?= count(array_filter($absPrev, fn($a) => !$a['justified'])) ?></b><span>بلا رخصة من أمس</span></div>
</div>

<section class="card">
  <h2 class="card-title">حضور الأساتذة</h2>
  <?php if (!$byTeacher): ?>
    <p class="empty">لا توجد حصص مبرمجة يوم <?= e(AR_DAYS[$dow]) ?>. أضفها من صفحة التوقيت.</p>
  <?php else: ?>
    <ul class="list">
      <?php foreach ($byTeacher as $list): $signedN = count(array_filter($list, fn($r) => $r['signed_at'])); ?>
        <li style="align-items:flex-start">
          <div class="li-main">
            <div class="li-title"><?= e($list[0]['full_name']) ?></div>
            <div class="btn-row" style="margin-top:6px">
              <?php foreach ($list as $r): ?>
                <span class="chip <?= $r['signed_at'] ? 'chip-ok' : 'chip-warn' ?>" title="<?= e($r['subject_name']) ?>">
                  <?= e(hm($r['start_time'])) ?> <?= e($r['label']) ?>
                  <?= $r['signed_at'] ? '✓ ' . e(date('H:i', strtotime($r['signed_at']))) : '✗' ?>
                </span>
              <?php endforeach; ?>
            </div>
          </div>
          <span class="chip <?= $signedN ? 'chip-ok' : 'chip-danger' ?>"><?= $signedN ? 'حاضر' : 'لم يوقّع' ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<?php $signedRows = array_filter($rows, fn($r) => $r['signed_at']); if ($signedRows): ?>
<details class="card">
  <summary class="card-title">التوقيعات بالتفصيل (<?= count($signedRows) ?>)</summary>
  <ul class="list">
    <?php foreach ($signedRows as $r): ?>
      <li>
        <img class="sig-thumb" src="<?= e($r['signature']) ?>" alt="توقيع">
        <div class="li-main">
          <div class="li-title"><?= e($r['full_name']) ?></div>
          <div class="li-sub"><?= e($r['subject_name']) ?> · <?= e($r['label']) ?> · <?= e(hm($r['start_time'])) ?> · غياب: <?= (int)$r['abs_count'] ?><?= $r['absences_submitted_at'] ? '' : ' (لم تُرسل)' ?></div>
        </div>
        <form method="post" action="<?= url('admin/actions.php') ?>" data-confirm="حذف هذا التوقيع والسماح للأستاذ بإعادة التوقيع؟">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="reset_signature">
          <input type="hidden" name="att_id" value="<?= (int)$r['att_id'] ?>">
          <input type="hidden" name="back" value="admin/index.php?date=<?= e($date) ?>">
          <button class="icon-btn danger" aria-label="حذف التوقيع"><?= icon('trash') ?></button>
        </form>
      </li>
    <?php endforeach; ?>
  </ul>
</details>
<?php endif; ?>

<section class="card">
  <h2 class="card-title">الغائبون يوم <?= e(ar_date($date)) ?></h2>
  <?php if (!$absToday): ?>
    <p class="empty">لا توجد غيابات مسجلة.</p>
  <?php else: ?>
    <?php $lastC = null; foreach ($absToday as $a): ?>
      <?php if ($a['label'] !== $lastC): $lastC = $a['label']; ?><p class="group-label">القسم <?= e($a['label']) ?></p><?php endif; ?>
      <div class="slot">
        <span class="li-main li-title"><?= e($a['full_name']) ?></span>
        <span class="chip chip-danger"><?= e($a['sessions']) ?></span>
      </div>
    <?php endforeach; ?>
    <p class="muted small">ص = الفترة الصباحية، م = المسائية، والرقم هو رقم الحصة.</p>
  <?php endif; ?>
</section>

<section class="card">
  <h2 class="card-title">غائبو <?= e(ar_date($prev)) ?> (رخصة الدخول)</h2>
  <p class="card-note">من لم يُشطب اسمه يُكتب بالأحمر في ورقة الغيابات. اضغط "شطب" عند تقديم التلميذ لرخصة الدخول.</p>
  <?php if (!$absPrev): ?>
    <p class="empty">لا يوجد.</p>
  <?php else: ?>
    <ul class="list">
      <?php foreach ($absPrev as $a): ?>
        <li>
          <div class="li-main">
            <div class="li-title <?= $a['justified'] ? 'strike' : '' ?>" style="<?= $a['justified'] ? '' : 'color:var(--danger)' ?>"><?= e($a['full_name']) ?></div>
            <div class="li-sub"><?= e($a['label']) ?> · <?= e($a['sessions']) ?></div>
          </div>
          <form method="post" action="<?= url('admin/actions.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_justify">
            <input type="hidden" name="student_id" value="<?= (int)$a['id'] ?>">
            <input type="hidden" name="date" value="<?= e($prev) ?>">
            <input type="hidden" name="value" value="<?= $a['justified'] ? 0 : 1 ?>">
            <input type="hidden" name="back" value="admin/index.php?date=<?= e($date) ?>">
            <button class="btn btn-sm <?= $a['justified'] ? 'btn-soft' : 'btn-ok' ?>"><?= $a['justified'] ? 'تراجع' : 'شطب' ?></button>
          </form>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
<?php page_end();
