<?php
/* التلاميذ: استيراد من Excel/CSV + إضافة يدوية + القوائم حسب القسم */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('admin');

$classes = all_classes();
$classId = (int)($_GET['class_id'] ?? ($classes[0]['id'] ?? 0));

$counts = [];
foreach (db()->query('SELECT class_id, COUNT(*) n FROM students WHERE is_active = 1 GROUP BY class_id') as $r) {
    $counts[$r['class_id']] = (int)$r['n'];
}

$st = db()->prepare('SELECT * FROM students WHERE class_id = ? AND is_active = 1 ORDER BY full_name');
$st->execute([$classId]);
$students = $st->fetchAll();
$total = array_sum($counts);

page_start('التلاميذ', 'students');
?>
<section class="card">
  <h2 class="card-title">استيراد قائمة التلاميذ</h2>
  <p class="card-note">ملف Excel (.xlsx) أو CSV يحتوي الأعمدة: اسم التلميذ، المستوى (أولى/ثانية/ثالثة/رابعة)، رقم الفوج. الأعمدة الاختيارية: رقم التعريف، تاريخ الميلاد، النظام، رقم التسجيل. يُتعرّف على الأعمدة من عناوينها.</p>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="import_students">
    <label class="field"><span>الملف</span>
      <input class="input" type="file" name="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" required></label>
    <div class="form-row">
      <label class="field"><span>اسم الورقة (اختياري)</span>
        <input class="input" name="sheet" placeholder="Data — فارغ = الورقة الأولى"></label>
      <label class="field"><span>طريقة الاستيراد</span>
        <select class="input" name="mode">
          <option value="upsert">تحديث وإضافة (حسب رقم التعريف)</option>
          <option value="replace">استبدال القائمة كاملة</option>
        </select></label>
    </div>
    <button class="btn btn-primary"><?= icon('upload') ?> استيراد</button>
  </form>
</section>

<details class="card">
  <summary class="card-title">إضافة تلميذ يدويا</summary>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_student">
    <label class="field"><span>الاسم واللقب</span><input class="input" name="full_name" required></label>
    <div class="form-row">
      <label class="field"><span>القسم</span>
        <select class="input" name="class_id">
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $classId ? 'selected' : '' ?>><?= e($c['label']) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>رقم التعريف (اختياري)</span><input class="input" name="national_id" dir="ltr" inputmode="numeric"></label>
    </div>
    <button class="btn btn-soft">إضافة</button>
  </form>
</details>

<section class="card">
  <form method="get" class="card-head">
    <h2 class="card-title">القوائم (<?= $total ?> تلميذ)</h2>
    <select class="input" name="class_id" data-autosubmit style="width:auto;min-width:130px">
      <?php foreach ($classes as $c): ?>
        <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $classId ? 'selected' : '' ?>><?= e($c['label']) ?> (<?= $counts[$c['id']] ?? 0 ?>)</option>
      <?php endforeach; ?>
    </select>
  </form>
  <?php if (!$students): ?>
    <p class="empty">لا يوجد تلاميذ في هذا القسم. استورد ملف Excel أعلاه.</p>
  <?php else: ?>
    <ul class="list">
      <?php foreach ($students as $i => $s): ?>
        <li>
          <span class="student-num"><?= $i + 1 ?></span>
          <div class="li-main">
            <div class="li-title"><?= e($s['full_name']) ?></div>
            <div class="li-sub">
              <?= $s['birth_date'] ? 'مواليد ' . e(date('d/m/Y', strtotime($s['birth_date']))) : '' ?>
              <?= $s['regime'] ? ' · ' . e($s['regime']) : '' ?>
              <?= $s['reg_number'] ? ' · رقم التسجيل ' . e($s['reg_number']) : '' ?>
            </div>
          </div>
          <form method="post" action="<?= url('admin/actions.php') ?>" data-confirm="حذف التلميذ <?= e($s['full_name']) ?>؟">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_student">
            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
            <input type="hidden" name="back" value="admin/students.php?class_id=<?= $classId ?>">
            <button class="icon-btn danger" aria-label="حذف"><?= icon('trash') ?></button>
          </form>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
<?php page_end();
