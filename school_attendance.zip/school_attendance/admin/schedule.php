<?php
/* جدول التوقيت: إسناد (قسم + يوم + حصة) لأستاذ ومادة. خانتان كحد أقصى للفوج المقسم */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('admin');

$classes = all_classes();
$times   = all_session_times();
$classId = (int)($_GET['class_id'] ?? ($classes[0]['id'] ?? 0));
$dayPick = isset($_GET['day']) ? (int)$_GET['day'] : 0;

$teachers = db()->query("SELECT id, full_name FROM users WHERE role = 'teacher' AND status = 'active' ORDER BY full_name")->fetchAll();
$subjects = db()->query('SELECT id, name FROM subjects ORDER BY name')->fetchAll();
$tsMap = [];
foreach (db()->query('SELECT teacher_id, subject_id FROM teacher_subjects') as $r) {
    $tsMap[$r['teacher_id']][] = (int)$r['subject_id'];
}

// جدول القسم المختار
$st = db()->prepare(
    "SELECT cs.id, cs.day_of_week, cs.session_time_id, u.full_name, s.name AS subject_name, s.short_name
       FROM classes_schedule cs
       JOIN users u    ON u.id = cs.teacher_id
       JOIN subjects s ON s.id = cs.subject_id
      WHERE cs.class_id = ? AND cs.is_active = 1
   ORDER BY cs.id"
);
$st->execute([$classId]);
$grid = [];
foreach ($st->fetchAll() as $r) $grid[$r['day_of_week']][$r['session_time_id']][] = $r;

page_start('جدول التوقيت', 'schedule');
?>
<section class="card">
  <h2 class="card-title">إضافة حصة</h2>
  <p class="card-note">لتقسيم الفوج (مثل عر / ريا) أضف أستاذين لنفس القسم واليوم والحصة.</p>
  <?php if (!$teachers): ?>
    <p class="empty">أضف أستاذا مفعّلا أولا من صفحة الأساتذة.</p>
  <?php else: ?>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_schedule">
    <div class="form-row">
      <label class="field"><span>القسم</span>
        <select class="input" name="class_id" required>
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $classId ? 'selected' : '' ?>><?= e($c['label']) ?> – <?= e(class_full_label($c['level'], $c['group_no'])) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>اليوم</span>
        <select class="input" name="day_of_week" required>
          <?php foreach (SCHOOL_DAYS as $d): ?>
            <option value="<?= $d ?>" <?= $d === $dayPick ? 'selected' : '' ?>><?= e(AR_DAYS[$d]) ?></option>
          <?php endforeach; ?>
        </select></label>
    </div>
    <label class="field"><span>الحصة</span>
      <select class="input" name="session_time_id" required>
        <?php foreach ($times as $t): ?>
          <option value="<?= (int)$t['id'] ?>"><?= e(PERIODS[$t['period']]) ?> – الحصة <?= (int)$t['session_no'] ?> (<?= e(hm($t['start_time'])) ?> - <?= e(hm($t['end_time'])) ?>)</option>
        <?php endforeach; ?>
      </select></label>
    <div class="form-row">
      <label class="field"><span>الأستاذ</span>
        <select class="input" name="teacher_id" id="teacherSel" required>
          <option value="">— اختر —</option>
          <?php foreach ($teachers as $t): ?>
            <option value="<?= (int)$t['id'] ?>" data-subjects="<?= e(json_encode($tsMap[$t['id']] ?? [])) ?>"><?= e($t['full_name']) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>المادة</span>
        <select class="input" name="subject_id" id="subjectSel" required>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select></label>
    </div>
    <button class="btn btn-primary">إضافة إلى الجدول</button>
  </form>
  <?php endif; ?>
</section>

<section class="card">
  <form method="get" class="card-head">
    <h2 class="card-title">جدول القسم</h2>
    <select class="input" name="class_id" data-autosubmit style="width:auto;min-width:120px">
      <?php foreach ($classes as $c): ?>
        <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $classId ? 'selected' : '' ?>><?= e($c['label']) ?></option>
      <?php endforeach; ?>
    </select>
  </form>

  <?php foreach (SCHOOL_DAYS as $d): ?>
    <div class="day-block">
      <p class="group-label"><?= e(AR_DAYS[$d]) ?></p>
      <?php foreach ($times as $t): ?>
        <div class="slot">
          <span class="slot-time"><?= $t['period'] === 'morning' ? 'ص' : 'م' ?><?= (int)$t['session_no'] ?> · <?= e(hm($t['start_time'])) ?></span>
          <span class="slot-items">
            <?php foreach ($grid[$d][$t['id']] ?? [] as $en): ?>
              <span class="slot-entry">
                <?= e($en['subject_name']) ?> <span class="muted">– <?= e($en['full_name']) ?></span>
                <form method="post" action="<?= url('admin/actions.php') ?>" data-confirm="حذف هذه الحصة من الجدول؟">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete_schedule">
                  <input type="hidden" name="id" value="<?= (int)$en['id'] ?>">
                  <button aria-label="حذف">×</button>
                </form>
              </span>
            <?php endforeach; ?>
            <?php if (empty($grid[$d][$t['id']])): ?><span class="muted small">—</span><?php endif; ?>
          </span>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</section>

<script>
/* إظهار مواد الأستاذ المختار فقط */
(function () {
  var t = document.getElementById('teacherSel'), s = document.getElementById('subjectSel');
  if (!t || !s) return;
  t.addEventListener('change', function () {
    var opt = t.options[t.selectedIndex];
    var allowed = JSON.parse(opt.getAttribute('data-subjects') || '[]');
    var first = null;
    Array.prototype.forEach.call(s.options, function (o) {
      var ok = !allowed.length || allowed.indexOf(parseInt(o.value, 10)) !== -1;
      o.hidden = !ok; o.disabled = !ok;
      if (ok && first === null) first = o;
    });
    if (first) s.value = first.value;
  });
})();
</script>
<?php page_end();
