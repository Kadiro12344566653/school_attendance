<?php
/* ورقة الغيابات اليومية الجاهزة للطباعة (الفترة الصباحية + المسائية) — نفس تصميم الورقة الورقية */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('admin');

$date   = valid_date($_GET['date'] ?? null);
$which  = in_array($_GET['period'] ?? '', ['morning', 'evening'], true) ? $_GET['period'] : 'all';
$dow    = day_of_week($date);
$prev   = previous_school_day($date);

$classes = all_classes();
$times   = [];
foreach (all_session_times() as $t) $times[$t['period']][] = $t;

// المواد والتوقيعات لكل خانة (قسم × حصة)
$st = db()->prepare(
    "SELECT cs.id, cs.class_id, cs.session_time_id, s.name AS subject_name, s.short_name,
            u.full_name, ta.signature, ta.signed_at
       FROM classes_schedule cs
       JOIN subjects s ON s.id = cs.subject_id
       JOIN users u    ON u.id = cs.teacher_id
  LEFT JOIN teacher_attendance ta ON ta.schedule_id = cs.id AND ta.att_date = ?
      WHERE cs.day_of_week = ? AND (cs.is_active = 1 OR ta.id IS NOT NULL)
   ORDER BY cs.id"
);
$st->execute([$date, $dow]);
$cells = [];
foreach ($st->fetchAll() as $r) $cells[$r['class_id']][$r['session_time_id']][] = $r;

// الغائبون في كل حصة
$st = db()->prepare(
    "SELECT cs.class_id, cs.session_time_id, stu.full_name
       FROM student_absences sa
       JOIN classes_schedule cs ON cs.id = sa.schedule_id
       JOIN students stu        ON stu.id = sa.student_id
      WHERE sa.absence_date = ?
   ORDER BY stu.full_name"
);
$st->execute([$date]);
$absent = [];
foreach ($st->fetchAll() as $r) $absent[$r['class_id']][$r['session_time_id']][$r['full_name']] = true;

// الغائبون في اليوم الدراسي السابق (بالأحمر، ويُشطب من قدّم رخصة)
$st = db()->prepare(
    "SELECT stu.class_id, stu.full_name, MIN(sa.is_justified) AS justified
       FROM student_absences sa
       JOIN students stu ON stu.id = sa.student_id
      WHERE sa.absence_date = ?
   GROUP BY stu.id, stu.class_id, stu.full_name
   ORDER BY stu.full_name"
);
$st->execute([$prev]);
$prior = [];
foreach ($st->fetchAll() as $r) $prior[$r['class_id']][] = $r;

$periods = $which === 'all' ? ['morning', 'evening'] : [$which];
$dayName = AR_DAYS[$dow];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ورقة الغيابات <?= e(date('d-m-Y', strtotime($date))) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/print.css') ?>">
</head>
<body>

<form class="toolbar no-print" method="get">
  <a class="tb-btn" href="<?= url('admin/index.php?date=' . $date) ?>">رجوع</a>
  <input type="date" name="date" value="<?= e($date) ?>" onchange="this.form.submit()">
  <select name="period" onchange="this.form.submit()">
    <option value="all" <?= $which === 'all' ? 'selected' : '' ?>>الفترتان</option>
    <option value="morning" <?= $which === 'morning' ? 'selected' : '' ?>>الصباحية</option>
    <option value="evening" <?= $which === 'evening' ? 'selected' : '' ?>>المسائية</option>
  </select>
  <button type="button" class="tb-btn tb-primary" data-print>طباعة</button>
</form>

<?php if (!is_school_day($date)): ?>
  <p class="no-print notice">يوم <?= e($dayName) ?> ليس يوم دراسة. اختر تاريخا آخر.</p>
<?php endif; ?>

<div class="sheets">
<?php foreach ($periods as $period): $ts = $times[$period] ?? []; $n = count($ts); ?>
<section class="sheet sheet-<?= $n ?>">
  <header class="sheet-head">
    <div class="head-right">
      <p class="school"><?= e(SCHOOL_NAME) ?></p>
      <?php if ($period === 'morning'): ?>
        <h1>ورقة الغيابات ليوم: <?= e($dayName) ?> <?= e(date('d / m / Y', strtotime($date))) ?></h1>
      <?php endif; ?>
      <p class="period"><?= e(PERIODS[$period]) ?>
        <?php if ($period === 'evening'): ?><span class="date">التاريخ: <?= e($dayName) ?> <?= e(date('d / m / Y', strtotime($date))) ?></span><?php endif; ?>
      </p>
    </div>
    <?php if ($period === 'morning'): ?>
      <div class="warning">كل تلميذ غاب في اليوم السابق ولم يُشطب اسمه المسجل <b>بالأحمر</b> يجب طرده من القسم في الحين ليقدَّم لسكرتارية السيد الناظر، وذلك إن لم يكن حاملا معه رخصة للدخول مؤرخة في اليوم نفسه.</div>
    <?php endif; ?>
  </header>

  <table class="grid">
    <colgroup>
      <col class="w-class"><col class="w-prev">
      <?php for ($i = 0; $i < $n; $i++): ?><col class="w-abs"><?php endfor; ?>
      <?php for ($i = 0; $i < $n; $i++): ?><col class="w-sig"><?php endfor; ?>
    </colgroup>
    <thead>
      <tr>
        <th rowspan="2">الأقسام</th>
        <th rowspan="2" class="prev-head">التلاميذ الغائبون قبل اليوم لا يؤذن لهم بالدخول بدون رخصة يسلمها لهم السيد مستشار التربية</th>
        <th colspan="<?= $n ?>">أسماء التلاميذ الغائبين</th>
        <th colspan="<?= $n ?>">توقيع الأساتذة</th>
      </tr>
      <tr>
        <?php foreach ($ts as $t): ?>
          <th class="time-head">من <?= e(sheet_time($t['start_time'])) ?><br>إلى <?= e(sheet_time($t['end_time'])) ?></th>
        <?php endforeach; ?>
        <?php foreach ($ts as $t): ?><th>الحصة <?= (int)$t['session_no'] ?></th><?php endforeach; ?>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($classes as $c): ?>
      <tr class="r-subj">
        <td rowspan="2" class="class-cell"><?= e($c['label']) ?></td>
        <td rowspan="2" class="prev-cell">
          <?php foreach ($prior[$c['id']] ?? [] as $p): ?>
            <span class="<?= $p['justified'] ? 'struck' : '' ?>"><?= e($p['full_name']) ?></span>
          <?php endforeach; ?>
        </td>
        <?php foreach ($ts as $t): ?>
          <td rowspan="2" class="abs-cell"><?= e(implode('، ', array_keys($absent[$c['id']][$t['id']] ?? []))) ?></td>
        <?php endforeach; ?>
        <?php foreach ($ts as $t):
            $entries = $cells[$c['id']][$t['id']] ?? [];
            if (PRINT_SUBJECT_ONLY_IF_SIGNED) $entries = array_values(array_filter($entries, fn($x) => $x['signature']));
        ?>
          <td class="subj-cell"><?= e(subjects_cell_text($entries)) ?></td>
        <?php endforeach; ?>
      </tr>
      <tr class="r-sig">
        <?php foreach ($ts as $t): $entries = $cells[$c['id']][$t['id']] ?? []; ?>
          <td class="sig-cell<?= count($entries) > 1 ? ' split' : '' ?>">
            <?php foreach ($entries as $en): ?>
              <?php if ($en['signature']): ?>
                <img src="<?= e($en['signature']) ?>" alt="" title="<?= e($en['full_name'] . ' – ' . date('H:i', strtotime($en['signed_at']))) ?>">
              <?php elseif (count($entries) > 1): ?>
                <span class="sig-empty"></span>
              <?php endif; ?>
            <?php endforeach; ?>
          </td>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <footer class="sheet-foot">
    <span>اسم وإمضاء العون المكلف: ..............................</span>
    <span>مستشار التربية</span>
  </footer>
</section>
<?php endforeach; ?>
</div>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
