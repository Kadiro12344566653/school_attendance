<?php
/* إدارة الأساتذة والمواد */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('admin');

$subjects = db()->query('SELECT * FROM subjects ORDER BY name')->fetchAll();

$teachers = db()->query(
    "SELECT u.*,
            (SELECT GROUP_CONCAT(s.name ORDER BY s.name SEPARATOR '، ')
               FROM teacher_subjects ts JOIN subjects s ON s.id = ts.subject_id
              WHERE ts.teacher_id = u.id) AS subjects,
            (SELECT COUNT(*) FROM classes_schedule cs WHERE cs.teacher_id = u.id AND cs.is_active = 1) AS sessions
       FROM users u
      WHERE u.role = 'teacher'
   ORDER BY FIELD(u.status,'pending','active','disabled'), u.reset_requested DESC, u.full_name"
)->fetchAll();

// وضع التعديل
$edit = null;
$editSubjects = [];
if (!empty($_GET['edit'])) {
    $st = db()->prepare("SELECT * FROM users WHERE id = ? AND role = 'teacher'");
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch() ?: null;
    if ($edit) {
        $st = db()->prepare('SELECT subject_id FROM teacher_subjects WHERE teacher_id = ?');
        $st->execute([$edit['id']]);
        $editSubjects = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }
}
$statusLabel = ['active' => ['مفعّل', 'chip-ok'], 'pending' => ['في الانتظار', 'chip-warn'], 'disabled' => ['موقوف', 'chip-danger']];

page_start('الأساتذة والمواد', 'teachers');
?>
<section class="card" id="form">
  <h2 class="card-title"><?= $edit ? 'تعديل: ' . e($edit['full_name']) : 'إضافة أستاذ' ?></h2>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>" style="margin-top:12px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="<?= $edit ? 'update_teacher' : 'add_teacher' ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div class="form-row">
      <label class="field"><span>الاسم الكامل</span>
        <input class="input" name="full_name" required value="<?= e($edit['full_name'] ?? '') ?>" placeholder="مثال: هشام بدارني"></label>
      <label class="field"><span>البريد الإلكتروني</span>
        <input class="input" type="email" name="email" dir="ltr" required value="<?= e($edit['email'] ?? '') ?>"></label>
    </div>
    <div class="form-row">
      <label class="field"><span>الهاتف</span>
        <input class="input" type="tel" name="phone" dir="ltr" value="<?= e($edit['phone'] ?? '') ?>"></label>
      <label class="field"><span><?= $edit ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء)' : 'كلمة المرور' ?></span>
        <input class="input" type="text" name="password" dir="ltr" <?= $edit ? '' : 'required' ?> minlength="6" autocomplete="new-password"></label>
    </div>
    <div class="field">
      <span>المواد التي يدرّسها</span>
      <div class="checks">
        <?php foreach ($subjects as $s): ?>
          <label class="pill-check">
            <input type="checkbox" name="subjects[]" value="<?= (int)$s['id'] ?>" <?= in_array((int)$s['id'], $editSubjects, true) ? 'checked' : '' ?>>
            <span><?= e($s['name']) ?></span>
          </label>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-primary" style="flex:1"><?= $edit ? 'حفظ التعديلات' : 'إضافة الأستاذ' ?></button>
      <?php if ($edit): ?><a class="btn btn-ghost" href="<?= url('admin/teachers.php') ?>">إلغاء</a><?php endif; ?>
    </div>
  </form>
</section>

<section class="card">
  <h2 class="card-title">قائمة الأساتذة (<?= count($teachers) ?>)</h2>
  <?php if (!$teachers): ?><p class="empty">لم تُضف أي أستاذ بعد.</p><?php endif; ?>
  <ul class="list">
    <?php foreach ($teachers as $t): [$sl, $sc] = $statusLabel[$t['status']]; ?>
      <li style="align-items:flex-start;flex-wrap:wrap">
        <div class="li-main">
          <div class="li-title"><?= e($t['full_name']) ?></div>
          <div class="li-sub" dir="ltr" style="text-align:right"><?= e($t['email']) ?></div>
          <div class="li-sub"><?= $t['subjects'] ? e($t['subjects']) : '<span style="color:var(--danger)">بدون مادة</span>' ?> · <?= (int)$t['sessions'] ?> حصة/أسبوع</div>
          <div class="btn-row" style="margin-top:6px">
            <span class="chip <?= $sc ?>"><?= $sl ?></span>
            <?php if ($t['reset_requested']): ?><span class="chip chip-warn">طلب كلمة مرور جديدة</span><?php endif; ?>
          </div>
        </div>
        <div class="li-side">
          <a class="btn btn-sm btn-soft" href="<?= url('admin/teachers.php?edit=' . $t['id']) ?>#form">تعديل</a>
          <form method="post" action="<?= url('admin/actions.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="set_status">
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <?php if ($t['status'] === 'active'): ?>
              <input type="hidden" name="status" value="disabled"><button class="btn btn-sm btn-danger">إيقاف</button>
            <?php else: ?>
              <input type="hidden" name="status" value="active"><button class="btn btn-sm btn-ok">تفعيل</button>
            <?php endif; ?>
          </form>
          <form method="post" action="<?= url('admin/actions.php') ?>" data-confirm="حذف الأستاذ نهائيا مع حصصه وتوقيعاته؟">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_teacher">
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <button class="icon-btn danger" aria-label="حذف"><?= icon('trash') ?></button>
          </form>
        </div>
      </li>
    <?php endforeach; ?>
  </ul>
</section>

<section class="card">
  <h2 class="card-title">المواد</h2>
  <p class="card-note">الاختصار يُكتب في ورقة الغياب عندما تجتمع مادتان في خانة واحدة (مثل: عر / ريا).</p>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="add_subject">
    <div class="form-row">
      <label class="field"><span>اسم المادة</span><input class="input" name="name" required placeholder="تربية مدنية"></label>
      <label class="field"><span>الاختصار</span><input class="input" name="short_name" required maxlength="20" placeholder="ت.مدنية"></label>
    </div>
    <button class="btn btn-soft">إضافة مادة</button>
  </form>
  <ul class="list" style="margin-top:8px">
    <?php foreach ($subjects as $s): ?>
      <li>
        <span class="li-main li-title"><?= e($s['name']) ?></span>
        <span class="chip"><?= e($s['short_name']) ?></span>
        <form method="post" action="<?= url('admin/actions.php') ?>" data-confirm="حذف المادة؟">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete_subject">
          <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <button class="icon-btn danger" aria-label="حذف"><?= icon('trash') ?></button>
        </form>
      </li>
    <?php endforeach; ?>
  </ul>
</section>

<details class="card">
  <summary class="card-title">كلمة مرور المدير</summary>
  <form class="form" method="post" action="<?= url('admin/actions.php') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="change_own_password">
    <label class="field"><span>كلمة المرور الحالية</span><input class="input" type="password" name="current" dir="ltr" required></label>
    <label class="field"><span>كلمة المرور الجديدة</span><input class="input" type="password" name="new" dir="ltr" required minlength="8"></label>
    <button class="btn btn-primary">تغيير</button>
  </form>
</details>
<?php page_end();
