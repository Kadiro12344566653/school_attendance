<?php
require_once __DIR__ . '/includes/auth_layout.php';
auth_start('الشروط وسياسة الخصوصية');
?>
      <h1 class="login-title">الشروط</h1>
      <div class="prose">
        <p>هذا التطبيق مخصص لطاقم <?= e(SCHOOL_NAME) ?> فقط، لتسجيل حضور الأساتذة وغيابات التلاميذ.</p>
        <p>يلتزم كل أستاذ بتسجيل الغيابات بدقة في حصصه، والتوقيع بنفسه. التوقيع الرقمي له نفس قيمة التوقيع على الورقة.</p>
      </div>
      <h2 class="login-title" id="privacy" style="font-size:1.2rem">سياسة الخصوصية</h2>
      <div class="prose">
        <p>تُحفظ أسماء التلاميذ والغيابات والتوقيعات على خادم المؤسسة فقط، ولا تُشارك مع أي جهة خارجية.</p>
        <p>لا يطّلع على البيانات إلا المدير والأساتذة المعنيون بأقسامهم.</p>
      </div>
      <a href="<?= url('index.php') ?>" class="btn-primary">رجوع</a>
<?php auth_end();
