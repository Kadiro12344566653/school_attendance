<?php
/* صفحة تسجيل الدخول */
require_once __DIR__ . '/includes/auth_layout.php';

if ($u = current_user()) redirect(home_for_role($u['role']));

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // حماية بسيطة من التخمين: 5 محاولات ثم انتظار 5 دقائق
    $_SESSION['login_fail'] = $_SESSION['login_fail'] ?? ['n' => 0, 't' => 0];
    $lock = $_SESSION['login_fail'];
    if ($lock['n'] >= 5 && time() - $lock['t'] < 300) {
        $error = 'محاولات كثيرة. حاول بعد ' . ceil((300 - (time() - $lock['t'])) / 60) . ' دقائق.';
    } elseif (empty($_POST['terms'])) {
        $error = 'يجب الموافقة على الشروط وسياسة الخصوصية.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'أدخل بريدا إلكترونيا صحيحا وكلمة المرور.';
    } else {
        $st = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $st->execute([$email]);
        $user = $st->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $_SESSION['login_fail'] = ['n' => $lock['n'] + 1, 't' => time()];
            $error = 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
        } elseif ($user['status'] === 'pending') {
            $error = 'حسابك في انتظار تفعيل المدير.';
        } elseif ($user['status'] === 'disabled') {
            $error = 'هذا الحساب موقوف. تواصل مع الإدارة.';
        } else {
            unset($_SESSION['login_fail']);
            if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
                db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                    ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
            }
            login_user($user);
            redirect(home_for_role($user['role']));
        }
    }
}

auth_start('تسجيل الدخول');
?>
      <h1 class="login-title">مرحبا بك</h1>
      <p class="login-sub">سجّل دخولك لمتابعة الحصص والغيابات</p>

      <?php if ($error): ?><div class="alert" role="alert"><?= e($error) ?></div><?php endif; ?>
      <?php foreach (take_flashes() as $f): ?><div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>

      <form method="post" class="login-form" id="loginForm" novalidate>
        <?= csrf_field() ?>
        <label class="field">
          <span class="field-label">البريد الإلكتروني</span>
          <span class="input-wrap">
            <?= icon('mail') ?>
            <input type="email" name="email" inputmode="email" autocomplete="username" dir="ltr"
                   placeholder="name@school.dz" value="<?= e($email) ?>" required>
          </span>
        </label>

        <label class="field">
          <span class="field-label">كلمة المرور</span>
          <span class="input-wrap">
            <?= icon('lock') ?>
            <input type="password" name="password" id="password" autocomplete="current-password" dir="ltr"
                   placeholder="••••••••" required>
            <button type="button" class="eye-btn" data-toggle-password="password" aria-label="إظهار كلمة المرور" aria-pressed="false">
              <span class="eye-show"><?= icon('eye') ?></span>
              <span class="eye-hide"><?= icon('eye-off') ?></span>
            </button>
          </span>
        </label>

        <div class="row-end">
          <a href="<?= url('forgot.php') ?>" class="link">نسيت كلمة المرور؟</a>
        </div>

        <button type="submit" class="btn-primary">تسجيل الدخول</button>

        <div class="divider"><span>أو</span></div>

        <a href="<?= url('register.php') ?>" class="btn-ghost">إنشاء حساب جديد</a>

        <label class="check">
          <input type="checkbox" name="terms" value="1" id="terms" required>
          <span class="check-box" aria-hidden="true"><?= icon('check') ?></span>
          <span>أوافق على <a href="<?= url('terms.php') ?>" class="link">الشروط</a> و<a href="<?= url('terms.php#privacy') ?>" class="link">سياسة الخصوصية</a></span>
        </label>
      </form>
<?php auth_end();
