/* صفحة الحصة عند الأستاذ: التوقيع ثم تسجيل الغيابات */
(function () {
  var root = document.getElementById('sessionPage');
  if (!root) return;
  var scheduleId = root.dataset.schedule;
  var api = root.dataset.api;

  /* ---------- الخطوة 1: التوقيع ---------- */
  var canvas = document.getElementById('sigCanvas');
  if (canvas) {
    var hint = document.querySelector('.sig-hint');
    var saveBtn = document.getElementById('sigSave');
    var pad = SignaturePad(canvas, {
      onBegin: function () { hint.hidden = true; saveBtn.disabled = false; },
      onClear: function () { hint.hidden = false; saveBtn.disabled = true; }
    });
    document.getElementById('sigClear').addEventListener('click', pad.clear);

    saveBtn.addEventListener('click', function () {
      if (pad.isEmpty()) { App.toast('ارسم توقيعك أولا.', 'error'); return; }
      saveBtn.disabled = true;
      saveBtn.textContent = 'جارٍ الحفظ…';
      App.post(api, { action: 'sign', schedule_id: scheduleId, signature: pad.toDataURL() }).then(function (res) {
        if (res.ok) {
          App.toast('تم تسجيل حضورك على الساعة ' + res.time);
          setTimeout(function () { location.reload(); }, 700);
        } else {
          App.toast(res.error || 'تعذر الحفظ.', 'error');
          saveBtn.disabled = false;
          saveBtn.textContent = 'حفظ التوقيع وتسجيل الحضور';
        }
      });
    });
  }

  /* ---------- الخطوة 2: الغيابات ---------- */
  var list = document.getElementById('studentList');
  if (!list) return;
  var counter = document.getElementById('absentCount');
  var submit = document.getElementById('absSubmit');

  function refresh() {
    var n = 0;
    list.querySelectorAll('.student-row').forEach(function (row) {
      var cb = row.querySelector('input');
      row.classList.toggle('is-absent', cb.checked);
      row.querySelector('.switch-label').textContent = cb.checked ? 'غائب' : 'حاضر';
      if (cb.checked) n++;
    });
    counter.textContent = n === 0 ? 'الجميع حاضرون' : ('الغائبون: ' + n);
  }
  list.addEventListener('change', refresh);
  refresh();

  var search = document.getElementById('studentSearch');
  if (search) search.addEventListener('input', function () {
    var q = search.value.trim();
    list.querySelectorAll('.student-row').forEach(function (row) {
      row.hidden = q !== '' && row.dataset.name.indexOf(q) === -1;
    });
  });

  submit.addEventListener('click', function () {
    var ids = Array.prototype.map.call(list.querySelectorAll('input:checked'), function (c) { return parseInt(c.value, 10); });
    submit.disabled = true;
    App.post(api, { action: 'absences', schedule_id: scheduleId, student_ids: ids }).then(function (res) {
      submit.disabled = false;
      if (res.ok) {
        App.toast(res.message);
        var st = document.getElementById('absState');
        if (st) { st.className = 'chip chip-ok'; st.textContent = 'أُرسلت ' + res.time; }
      } else {
        App.toast(res.error || 'تعذر الإرسال.', 'error');
      }
    });
  });
})();
