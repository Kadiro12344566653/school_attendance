/* لوحة توقيع HTML5 Canvas تدعم اللمس والفأرة والقلم (Pointer Events) */
function SignaturePad(canvas, opts) {
  opts = opts || {};
  var ctx = canvas.getContext('2d');
  var drawing = false, empty = true, last = null, strokes = [];
  var color = opts.color || '#0b2a6b';

  function resize() {
    var ratio = Math.max(window.devicePixelRatio || 1, 1);
    var rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * ratio;
    canvas.height = rect.height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    redraw();
  }

  function pos(ev) {
    var r = canvas.getBoundingClientRect();
    return { x: ev.clientX - r.left, y: ev.clientY - r.top, p: ev.pressure || 0.5 };
  }

  function lineWidth(p) { return 1.6 + p * 2.2; }

  function segment(a, b) {
    ctx.strokeStyle = color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = lineWidth(b.p);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    // منحنى ناعم عبر نقطة المنتصف
    var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    ctx.quadraticCurveTo(a.x, a.y, mx, my);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  function redraw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    strokes.forEach(function (s) {
      if (s.length === 1) dot(s[0]);
      for (var i = 1; i < s.length; i++) segment(s[i - 1], s[i]);
    });
  }

  function dot(pt) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, lineWidth(pt.p) / 2, 0, Math.PI * 2);
    ctx.fill();
  }

  canvas.addEventListener('pointerdown', function (ev) {
    ev.preventDefault();
    canvas.setPointerCapture(ev.pointerId);
    drawing = true;
    last = pos(ev);
    strokes.push([last]);
    dot(last);
    if (empty) { empty = false; if (opts.onBegin) opts.onBegin(); }
  });
  canvas.addEventListener('pointermove', function (ev) {
    if (!drawing) return;
    ev.preventDefault();
    var p = pos(ev);
    if (Math.abs(p.x - last.x) + Math.abs(p.y - last.y) < 1.2) return;
    segment(last, p);
    strokes[strokes.length - 1].push(p);
    last = p;
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (t) {
    canvas.addEventListener(t, function () { drawing = false; });
  });

  window.addEventListener('resize', resize);
  resize();

  return {
    clear: function () { strokes = []; empty = true; redraw(); if (opts.onClear) opts.onClear(); },
    isEmpty: function () { return empty; },
    /* صورة PNG مقصوصة على حدود التوقيع لتصغير الحجم */
    toDataURL: function () {
      var ratio = canvas.width / canvas.getBoundingClientRect().width;
      var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      strokes.forEach(function (s) { s.forEach(function (p) {
        minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
      }); });
      var pad = 8;
      minX = Math.max(0, minX - pad); minY = Math.max(0, minY - pad);
      var w = Math.min(canvas.width / ratio, maxX + pad) - minX;
      var h = Math.min(canvas.height / ratio, maxY + pad) - minY;
      var out = document.createElement('canvas');
      var scale = Math.min(1, 480 / w);             // لا يتجاوز عرضها 480px
      out.width = Math.max(1, Math.round(w * scale));
      out.height = Math.max(1, Math.round(h * scale));
      out.getContext('2d').drawImage(canvas, minX * ratio, minY * ratio, w * ratio, h * ratio, 0, 0, out.width, out.height);
      return out.toDataURL('image/png');
    }
  };
}
