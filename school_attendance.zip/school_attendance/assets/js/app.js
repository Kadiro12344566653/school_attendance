/* سلوك مشترك لكل صفحات التطبيق */
var App = (function () {
  var csrf = (document.querySelector('meta[name="csrf"]') || {}).content || '';

  // تمييز عنصر الشريط السفلي النشط
  var active = (document.querySelector('.page') || {}).dataset;
  if (active && active.active) {
    var a = document.querySelector('.bottomnav a[data-key="' + active.active + '"]');
    if (a) a.classList.add('is-active');
  }

  function hideToasts() {
    document.querySelectorAll('.toast').forEach(function (t) {
      setTimeout(function () { t.classList.add('hide'); setTimeout(function () { t.remove(); }, 400); }, 3500);
    });
  }
  hideToasts();

  function toast(msg, type) {
    var box = document.querySelector('.toasts');
    var t = document.createElement('div');
    t.className = 'toast toast-' + (type || 'success');
    t.setAttribute('role', 'status');
    t.textContent = msg;
    box.appendChild(t);
    hideToasts();
  }

  // تأكيد قبل الحذف: <form data-confirm="...">
  document.addEventListener('submit', function (ev) {
    var msg = ev.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) ev.preventDefault();
  });

  // إرسال تلقائي عند تغيير القائمة: <select data-autosubmit>
  document.querySelectorAll('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { el.form.submit(); });
  });

  function post(url, data) {
    return fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-Token': csrf
      },
      body: JSON.stringify(data)
    }).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: 'استجابة غير متوقعة من الخادم.' }; });
    }).catch(function () {
      return { ok: false, error: 'تعذر الاتصال بالخادم. تحقق من الشبكة.' };
    });
  }

  // الطباعة: داخل تطبيق Android نستدعي الجسر AndroidPrint إن وُجد
  function print() {
    if (window.AndroidPrint && typeof window.AndroidPrint.print === 'function') {
      window.AndroidPrint.print(document.title);
    } else {
      window.print();
    }
  }
  document.querySelectorAll('[data-print]').forEach(function (b) { b.addEventListener('click', print); });

  return { toast: toast, post: post, print: print };
})();
