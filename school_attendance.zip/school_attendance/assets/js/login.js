/* إظهار/إخفاء كلمة المرور + تذكر الموافقة على الشروط */
(function () {
  document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.dataset.togglePassword);
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
      input.focus({ preventScroll: true });
    });
  });

  var terms = document.getElementById('terms');
  var KEY = 'attendance_terms_ok';
  if (terms) {
    try { if (localStorage.getItem(KEY) === '1') terms.checked = true; } catch (e) {}
    terms.addEventListener('change', function () {
      try { localStorage.setItem(KEY, terms.checked ? '1' : '0'); } catch (e) {}
    });
  }

  var form = document.getElementById('loginForm');
  if (form) {
    form.addEventListener('submit', function (ev) {
      if (terms && !terms.checked) {
        ev.preventDefault();
        var box = terms.closest('.check');
        box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake');
        terms.focus();
        return;
      }
      var btn = form.querySelector('.btn-primary');
      btn.disabled = true;
      btn.textContent = 'جارٍ الدخول…';
    });
  }
})();
