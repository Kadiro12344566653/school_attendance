# دفتر الغيابات — متوسطة الشهيد بدراني بوعمامة

## التشغيل على XAMPP
1. انسخ المجلد `school_attendance` إلى `C:\xampp\htdocs\`.
2. شغّل **Apache** و**MySQL** من لوحة XAMPP.
3. افتح `http://localhost/phpmyadmin` ← **Import** ← اختر `database/schema.sql` ← **Go**.
4. تحقق أن `extension=zip` مفعّل (بدون `;`) في `C:\xampp\php\php.ini` ثم أعد تشغيل Apache. (لازم لاستيراد Excel)
5. افتح `http://localhost/school_attendance`
   - المدير: `admin@school.dz` / `Admin@123` — غيّرها فورا من صفحة الأساتذة.
6. الترتيب المقترح:
   1. **التلاميذ**: استورد ملف Excel (الورقة الأولى أو اكتب `Data`).
   2. **الأساتذة**: أضف كل أستاذ وحدد مواده.
   3. **التوقيت**: لكل قسم/يوم/حصة اختر الأستاذ والمادة (أستاذان في الخانة = فوج مقسم: عر / ريا).
   4. الأستاذ يدخل من هاتفه ← يختار الحصة ← يوقّع ← يحدد الغائبين ← إرسال.
   5. المدير: **المتابعة** ثم **الطباعة**.

## الوصول من الهاتف
- اعرف IP الحاسوب بالأمر `ipconfig` (مثلا 192.168.1.10) واستعمل `http://192.168.1.10/school_attendance/`.
- اسمح لـ Apache في جدار حماية Windows.
- إن غيّرت اسم المجلد، عدّل `BASE_URL` في `config/config.php`.

## الإعدادات (config/config.php)
| الإعداد | المعنى |
|---|---|
| `STRICT_TIME_WINDOW` | منع التوقيع خارج وقت الحصة |
| `PRINT_SUBJECT_ONLY_IF_SIGNED` | لا تُكتب المادة في الورقة إلا بعد توقيع الأستاذ |
| `SCHOOL_NAME` | اسم المؤسسة في الورقة |
| `APP_DEBUG` | اجعلها `false` عند الاستعمال الفعلي |

## تطبيق Android
الملف `android/MainActivity.java` جاهز: WebView + رفع الملفات + جسر الطباعة `AndroidPrint` (A4 أفقي).
