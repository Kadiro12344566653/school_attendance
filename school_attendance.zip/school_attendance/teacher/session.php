<?php
/* حصة واحدة: التوقيع الرقمي ثم تسجيل الغيابات */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('teacher');

$id    = (int)($_GET['id'] ?? 0);
$today = date('Y-m-d');

$st = db()->prepare(
    "SELECT cs.*, c.label, c.level, c.group_no, s.name AS subject_name,
            t.period, t.session_no, t.start_time, t.end_time
       FROM classes_schedule cs
       JOIN classes c       ON c.id = cs.class_id
       JOIN subjects s      ON s.id = cs.subject_id
       JOIN session_times t ON t.id = cs.session_time_id
      WHERE cs.id = ? AND cs.teacher_id = ? AND cs.is_active = 1"
);
$st->execute([$id, $me['id']]);
$sess = $st->fetch();
if (!$sess) {
    flash('error', 'الحصة غير موجودة.');
    redirect('teacher/index.php');
}

$isToday = (int)$sess['day_of_week'] === day_of_week($today) && is_school_day($today);

$st = db()->prepare('SELECT * FROM teacher_attendance WHERE schedule_id = ? AND att_date = ?');
$st->execute([$id, $today]);
$att = $st->fetch();

// زميل في نفس الخانة (فوج مقسم)
$st = db()->prepare(
    "SELECT u.full_name, s.name FROM classes_schedule cs
       JOIN users u ON u.id = cs.teacher_id JOIN subjects s ON s.id = cs.subject_id
      WHERE cs.class_id = ? AND cs.day_of_week = ? AND cs.session_time_id = ? AND cs.id <> ? AND cs.is_active = 1"
);
$st->execute([$sess['class_id'], $sess['day_of_week'], $sess['session_time_id'], $id]);
$partners = $st->fetchAll();

$st = db()->prepare('SELECT id, full_name FROM students WHERE class_id = ? AND is_active = 1 ORDER BY full_name');
$st->execute([$sess['class_id']]);
$students = $st->fetchAll();

$st = db()->prepare('SELECT student_id FROM student_absences WHERE schedule_id = ? AND absence_date = ?');
$st->execute([$id, $today]);
$absent = array_flip($st->fetchAll(PDO::FETCH_COLUMN));

$windowOk = sign_window_ok($sess['start_time'], $sess['end_time']);

page_start($sess['subject_name'] . ' – ' . $sess['label'], 'today', 'teacher/index.php');
?>
<div id="sessionPage" data-schedule="<?= (int)$id ?>" data-api="<?= url('teacher/actions.php') ?>">

<section class="card">
  <div class="card-head">
    <div>
      <h2 class="card-title"><?= e($sess['subject_name']) ?></h2>
      <p class="muted small" style="margin:2px 0 0"><?= e(class_full_label($sess['level'], $sess['group_no'])) ?> (<?= e($sess['label']) ?>)</p>
    </div>
    <span class="chip"><?= e(hm($sess['start_time'])) ?> - <?= e(hm($sess['end_time'])) ?></span>
  </div>
  <div class="btn-row">
    <span class="chip"><?= e(PERIODS[$sess['period']]) ?> · الحصة <?= (int)$sess['session_no'] ?></span>
    <span class="chip"><?= e(AR_DAYS[$sess['day_of_week']]) ?></span>
    <?php foreach ($partners as $p): ?>
      <span class="chip chip-warn">مشتركة مع: <?= e($p['full_name']) ?> (<?= e($p['name']) ?>)</span>
    <?php endforeach; ?>
  </div>
</section>

<?php if (!$isToday): ?>
  <div class="card empty">هذه الحصة يوم <?= e(AR_DAYS[$sess['day_of_week']]) ?>. يمكنك التوقيع وتسجيل الغياب يوم الحصة فقط.</div>
<?php else: ?>

<section class="card">
  <h2 class="card-title">1. توقيع الحضور</h2>
  <?php if ($att): ?>
    <div class="sig-done">
      <img src="<?= e($att['signature']) ?>" alt="توقيعك">
      <div>
        <span class="chip chip-ok"><?= icon('check') ?> حضور مسجل</span>
        <p class="muted small" style="margin:6px 0 0">على الساعة <?= e(date('H:i', strtotime($att['signed_at']))) ?></p>
      </div>
    </div>
  <?php elseif (!$windowOk): ?>
    <p class="empty">التوقيع متاح من <?= SIGN_EARLY_MINUTES ?> دقائق قبل بداية الحصة إلى <?= SIGN_LATE_MINUTES ?> دقيقة بعد نهايتها.</p>
  <?php else: ?>
    <p class="card-note">ارسم توقيعك بإصبعك داخل الإطار.</p>
    <div class="sig-box">
      <canvas id="sigCanvas" aria-label="مساحة التوقيع"></canvas>
      <div class="sig-line"></div>
      <div class="sig-hint">وقّع هنا</div>
    </div>
    <div class="btn-row" style="margin-top:12px">
      <button type="button" class="btn btn-soft" id="sigClear">مسح</button>
      <button type="button" class="btn btn-primary" id="sigSave" style="flex:1" disabled>حفظ التوقيع وتسجيل الحضور</button>
    </div>
  <?php endif; ?>
</section>

<section class="card <?= $att ? '' : 'steps-locked' ?>" aria-disabled="<?= $att ? 'false' : 'true' ?>">
  <div class="card-head">
    <h2 class="card-title">2. غيابات التلاميذ</h2>
    <?php if ($att && $att['absences_submitted_at']): ?>
      <span class="chip chip-ok" id="absState">أُرسلت <?= e(date('H:i', strtotime($att['absences_submitted_at']))) ?></span>
    <?php else: ?>
      <span class="chip chip-warn" id="absState">لم تُرسل</span>
    <?php endif; ?>
  </div>
  <?php if (!$att): ?><p class="card-note">وقّع أولا لتتمكن من تسجيل الغيابات.</p><?php endif; ?>
  <p class="card-note">الجميع حاضرون افتراضيا. اضغط على اسم التلميذ الغائب.</p>

  <?php if (!$students): ?>
    <p class="empty">لا يوجد تلاميذ في هذا القسم. اطلب من المدير استيراد القائمة.</p>
  <?php else: ?>
    <input type="search" class="input search" id="studentSearch" placeholder="ابحث عن تلميذ…">
    <div id="studentList">
      <?php foreach ($students as $i => $s): ?>
        <label class="student-row" data-name="<?= e($s['full_name']) ?>">
          <span class="student-num"><?= $i + 1 ?></span>
          <span class="student-name"><?= e($s['full_name']) ?></span>
          <span class="switch">
            <input type="checkbox" value="<?= (int)$s['id'] ?>" <?= isset($absent[$s['id']]) ? 'checked' : '' ?> <?= $att ? '' : 'disabled' ?>>
            <span class="switch-label">حاضر</span>
            <span class="switch-track"></span>
          </span>
        </label>
      <?php endforeach; ?>
    </div>
    <div class="sticky-submit">
      <span class="count" id="absentCount"></span>
      <button type="button" class="btn btn-primary" id="absSubmit" <?= $att ? '' : 'disabled' ?>>إرسال الغيابات</button>
    </div>
  <?php endif; ?>
</section>
<?php endif; ?>
</div>
<?php page_end(['assets/js/signature.js', 'assets/js/session.js']);
