<?php
/* لوحة الأستاذ: حصص اليوم + الجدول الأسبوعي */
require_once __DIR__ . '/../includes/layout.php';
$me = require_role('teacher');

$today    = date('Y-m-d');
$sessions = is_school_day($today) ? teacher_sessions($me['id'], $today) : [];
$nowT     = date('H:i:s');

// الجدول الأسبوعي
$st = db()->prepare(
    "SELECT cs.day_of_week, c.label, s.name AS subject_name, t.start_time, t.end_time, t.period
       FROM classes_schedule cs
       JOIN classes c       ON c.id = cs.class_id
       JOIN subjects s      ON s.id = cs.subject_id
       JOIN session_times t ON t.id = cs.session_time_id
      WHERE cs.teacher_id = ? AND cs.is_active = 1
   ORDER BY cs.day_of_week, FIELD(t.period,'morning','evening'), t.session_no"
);
$st->execute([$me['id']]);
$week = [];
foreach ($st->fetchAll() as $r) $week[$r['day_of_week']][] = $r;

// موادي
$st = db()->prepare('SELECT s.name FROM teacher_subjects ts JOIN subjects s ON s.id = ts.subject_id WHERE ts.teacher_id = ?');
$st->execute([$me['id']]);
$mySubjects = $st->fetchAll(PDO::FETCH_COLUMN);

$signed = count(array_filter($sessions, fn($s) => $s['signed_at']));

page_start('حصص اليوم', 'today');
?>
<section class="card">
  <div class="card-head">
    <div>
      <h2 class="card-title"><?= e(ar_date($today)) ?></h2>
      <p class="muted small" style="margin:2px 0 0">
        <?= $mySubjects ? 'موادي: ' . e(implode('، ', $mySubjects)) : 'لم يُسند لك المدير أي مادة بعد.' ?>
      </p>
    </div>
    <?php if ($sessions): ?>
      <span class="chip <?= $signed === count($sessions) ? 'chip-ok' : '' ?>"><?= $signed ?> / <?= count($sessions) ?> موقّعة</span>
    <?php endif; ?>
  </div>
</section>

<?php if (!is_school_day($today)): ?>
  <div class="card empty">اليوم عطلة نهاية الأسبوع، لا توجد حصص.</div>
<?php elseif (!$sessions): ?>
  <div class="card empty">لا توجد لك حصص اليوم في جدول التوقيت.</div>
<?php else: ?>
  <?php $lastPeriod = null; foreach ($sessions as $s): ?>
    <?php if ($s['period'] !== $lastPeriod): $lastPeriod = $s['period']; ?>
      <p class="group-label"><?= e(PERIODS[$s['period']]) ?></p>
    <?php endif; ?>
    <?php $isNow = $nowT >= $s['start_time'] && $nowT <= $s['end_time']; ?>
    <a class="session-card<?= $isNow ? ' is-now' : '' ?>" href="<?= url('teacher/session.php?id=' . $s['id']) ?>">
      <div class="session-time">
        <?= e(hm($s['start_time'])) ?>
        <small><?= e(hm($s['end_time'])) ?></small>
      </div>
      <div class="session-body">
        <span class="session-subject"><?= e($s['subject_name']) ?></span>
        <span class="session-class"><?= e($s['label']) ?> · <?= e(class_full_label($s['level'], $s['group_no'])) ?></span>
        <span class="session-status">
          <?php if ($s['signed_at']): ?>
            <span class="chip chip-ok"><?= icon('check') ?> وقّعت <?= e(date('H:i', strtotime($s['signed_at']))) ?></span>
          <?php else: ?>
            <span class="chip chip-warn"><?= icon('pen') ?> لم توقّع</span>
          <?php endif; ?>
          <?php if ($s['absences_submitted_at']): ?>
            <span class="chip <?= $s['abs_count'] ? 'chip-danger' : 'chip-ok' ?>">غياب: <?= (int)$s['abs_count'] ?></span>
          <?php endif; ?>
          <?php if ($isNow): ?><span class="chip">جارية الآن</span><?php endif; ?>
        </span>
      </div>
    </a>
  <?php endforeach; ?>
<?php endif; ?>

<section class="card" id="week">
  <h2 class="card-title">جدولي الأسبوعي</h2>
  <?php if (!$week): ?>
    <p class="empty">لا توجد حصص مسندة إليك بعد.</p>
  <?php endif; ?>
  <?php foreach ($week as $dow => $rows): ?>
    <p class="group-label"><?= e(AR_DAYS[$dow]) ?></p>
    <ul class="list">
      <?php foreach ($rows as $r): ?>
        <li>
          <span class="chip"><?= e(hm($r['start_time'])) ?> - <?= e(hm($r['end_time'])) ?></span>
          <span class="li-main"><span class="li-title"><?= e($r['subject_name']) ?></span></span>
          <span class="chip"><?= e($r['label']) ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endforeach; ?>
</section>
<?php page_end();
