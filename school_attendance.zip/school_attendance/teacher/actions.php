<?php
/* واجهة JSON لأفعال الأستاذ: sign | absences */
require_once __DIR__ . '/../includes/auth.php';

$_SERVER['HTTP_ACCEPT'] = 'application/json'; // كل الأخطاء تعود JSON
$me = require_role('teacher');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'طريقة غير مسموحة.'], 405);
verify_csrf();

$in     = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $in['action'] ?? '';
$sid    = (int)($in['schedule_id'] ?? 0);
$today  = date('Y-m-d');

// التحقق من أن الحصة للأستاذ واليوم هو يومها
$st = db()->prepare(
    'SELECT cs.*, t.start_time, t.end_time FROM classes_schedule cs
       JOIN session_times t ON t.id = cs.session_time_id
      WHERE cs.id = ? AND cs.teacher_id = ? AND cs.is_active = 1'
);
$st->execute([$sid, $me['id']]);
$sess = $st->fetch();
if (!$sess) json_out(['ok' => false, 'error' => 'الحصة غير موجودة.'], 404);
if ((int)$sess['day_of_week'] !== day_of_week($today) || !is_school_day($today)) {
    json_out(['ok' => false, 'error' => 'لا يمكن التسجيل إلا يوم الحصة.'], 422);
}

switch ($action) {

    /* ---------- التوقيع الرقمي ---------- */
    case 'sign':
        if (!sign_window_ok($sess['start_time'], $sess['end_time'])) {
            json_out(['ok' => false, 'error' => 'خارج وقت التوقيع المسموح.'], 422);
        }
        $sig = (string)($in['signature'] ?? '');
        if (strlen($sig) > MAX_SIGNATURE_BYTES
            || !preg_match('#^data:image/png;base64,([A-Za-z0-9+/=]+)$#', $sig, $m)) {
            json_out(['ok' => false, 'error' => 'صورة التوقيع غير صالحة.'], 422);
        }
        $bin  = base64_decode($m[1], true);
        $info = $bin ? @getimagesizefromstring($bin) : false;
        if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] < 10 || $info[1] < 5) {
            json_out(['ok' => false, 'error' => 'التوقيع فارغ أو تالف، أعد المحاولة.'], 422);
        }
        try {
            db()->prepare(
                'INSERT INTO teacher_attendance (teacher_id, schedule_id, att_date, signature, signed_at, ip_address)
                 VALUES (?, ?, ?, ?, NOW(), ?)'
            )->execute([$me['id'], $sid, $today, $sig, $_SERVER['REMOTE_ADDR'] ?? null]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') json_out(['ok' => false, 'error' => 'سبق أن وقّعت لهذه الحصة اليوم.'], 409);
            throw $e;
        }
        json_out(['ok' => true, 'time' => date('H:i')]);

    /* ---------- إرسال الغيابات ---------- */
    case 'absences':
        $st = db()->prepare('SELECT id FROM teacher_attendance WHERE schedule_id = ? AND att_date = ?');
        $st->execute([$sid, $today]);
        $attId = $st->fetchColumn();
        if (!$attId) json_out(['ok' => false, 'error' => 'وقّع حضورك أولا.'], 422);

        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($in['student_ids'] ?? [])))));

        // التأكد من أن التلاميذ ينتمون لهذا القسم
        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $st = db()->prepare("SELECT id FROM students WHERE class_id = ? AND is_active = 1 AND id IN ($ph)");
            $st->execute(array_merge([$sess['class_id']], $ids));
            $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        }

        $pdo = db();
        $pdo->beginTransaction();
        try {
            // حذف من أُلغي غيابه فقط (للحفاظ على حالة "مبرر" إن وُجدت)
            if ($ids) {
                $ph = implode(',', array_fill(0, count($ids), '?'));
                $pdo->prepare("DELETE FROM student_absences WHERE schedule_id = ? AND absence_date = ? AND student_id NOT IN ($ph)")
                    ->execute(array_merge([$sid, $today], $ids));
            } else {
                $pdo->prepare('DELETE FROM student_absences WHERE schedule_id = ? AND absence_date = ?')->execute([$sid, $today]);
            }
            $ins = $pdo->prepare(
                'INSERT IGNORE INTO student_absences (student_id, schedule_id, absence_date, marked_by) VALUES (?, ?, ?, ?)'
            );
            foreach ($ids as $stuId) $ins->execute([$stuId, $sid, $today, $me['id']]);
            $pdo->prepare('UPDATE teacher_attendance SET absences_submitted_at = NOW() WHERE id = ?')->execute([$attId]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            json_out(['ok' => false, 'error' => 'تعذر الحفظ: ' . (APP_DEBUG ? $e->getMessage() : '')], 500);
        }
        $n = count($ids);
        json_out([
            'ok'      => true,
            'count'   => $n,
            'time'    => date('H:i'),
            'message' => $n ? "تم إرسال الغيابات ($n غائب)." : 'تم الإرسال: الجميع حاضرون.',
        ]);

    default:
        json_out(['ok' => false, 'error' => 'إجراء غير معروف.'], 400);
}
