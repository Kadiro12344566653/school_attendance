package dz.school.attendance;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * غلاف WebView للتطبيق.
 * - غيّر APP_URL إلى عنوان IP الحاسوب الذي يشغّل XAMPP.
 * - في AndroidManifest.xml أضف:
 *     <uses-permission android:name="android.permission.INTERNET"/>
 *   وداخل <application>:  android:usesCleartextTraffic="true"   (لأن الرابط http)
 */
public class MainActivity extends Activity {

    private static final String APP_URL = "http://192.168.1.10/school_attendance/";
    private static final int FILE_REQUEST = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);      // التوقيع والغيابات
        s.setDomStorageEnabled(true);      // تذكّر خانة الشروط
        s.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient()); // فتح الروابط داخل التطبيق
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");

        // رفع ملف Excel/CSV من الهاتف (صفحة التلاميذ)
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "اختر الملف"), FILE_REQUEST);
                return true;
            }
        });

        webView.loadUrl(APP_URL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    /** window.print() لا يعمل في WebView؛ app.js يستدعي AndroidPrint.print() بدلا منه */
    private class PrintBridge {
        @JavascriptInterface
        public void print(final String title) {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(title);
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                        .build();
                pm.print(title, adapter, attrs);   // طابعة أو حفظ PDF
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
