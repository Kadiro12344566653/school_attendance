-- =====================================================================
--  نظام تسيير الغيابات - متوسطة الشهيد بدراني بوعمامة
--  MySQL / MariaDB schema  (XAMPP)
--  الاستيراد: phpMyAdmin > Import > schema.sql
-- =====================================================================

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS school_attendance
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE school_attendance;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS student_absences;
DROP TABLE IF EXISTS teacher_attendance;
DROP TABLE IF EXISTS classes_schedule;
DROP TABLE IF EXISTS session_times;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS teacher_subjects;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- المستخدمون: المدير والأساتذة
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name        VARCHAR(120) NOT NULL,
  email            VARCHAR(150) NOT NULL UNIQUE,
  password_hash    VARCHAR(255) NOT NULL,
  role             ENUM('admin','teacher') NOT NULL DEFAULT 'teacher',
  phone            VARCHAR(30)  NULL,
  status           ENUM('active','pending','disabled') NOT NULL DEFAULT 'active',
  reset_requested  TINYINT(1)   NOT NULL DEFAULT 0,
  last_login       DATETIME     NULL,
  created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- المواد (short_name يُستعمل عند كتابة مادتين في خانة واحدة: عر / ريا)
-- ---------------------------------------------------------------------
CREATE TABLE subjects (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80) NOT NULL UNIQUE,
  short_name  VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

-- المواد التي يدرّسها كل أستاذ (يحددها المدير)
CREATE TABLE teacher_subjects (
  teacher_id  INT UNSIGNED NOT NULL,
  subject_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (teacher_id, subject_id),
  CONSTRAINT fk_ts_teacher FOREIGN KEY (teacher_id) REFERENCES users(id)    ON DELETE CASCADE,
  CONSTRAINT fk_ts_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- الأقسام: المستوى (1..4) + رقم الفوج  => 1م1 ، 2م2 ...
-- ---------------------------------------------------------------------
CREATE TABLE classes (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  level     TINYINT UNSIGNED NOT NULL,
  group_no  TINYINT UNSIGNED NOT NULL,
  label     VARCHAR(20) NOT NULL UNIQUE,
  UNIQUE KEY uq_level_group (level, group_no)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- التلاميذ (نفس أعمدة ملف Excel: رقم تعريف، الاسم، تاريخ الميلاد، المستوى، الفوج، النظام، رقم التسجيل)
-- ---------------------------------------------------------------------
CREATE TABLE students (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  national_id  VARCHAR(30)  NULL UNIQUE,
  full_name    VARCHAR(150) NOT NULL,
  birth_date   DATE         NULL,
  class_id     INT UNSIGNED NOT NULL,
  regime       VARCHAR(30)  NULL,
  reg_number   VARCHAR(20)  NULL,
  is_active    TINYINT(1)   NOT NULL DEFAULT 1,
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_students_class (class_id),
  CONSTRAINT fk_students_class FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- توقيت الحصص (حسب ورقة الغياب)
-- ---------------------------------------------------------------------
CREATE TABLE session_times (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  period      ENUM('morning','evening') NOT NULL,
  session_no  TINYINT UNSIGNED NOT NULL,
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  UNIQUE KEY uq_period_session (period, session_no)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- جدول التوقيت: قسم + يوم + حصة + أستاذ + مادة
-- يُسمح بأستاذين في نفس الخانة (أفواج مقسمة: عر / ريا)
-- day_of_week: 0=الأحد 1=الاثنين 2=الثلاثاء 3=الأربعاء 4=الخميس
-- ---------------------------------------------------------------------
CREATE TABLE classes_schedule (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  class_id         INT UNSIGNED NOT NULL,
  day_of_week      TINYINT UNSIGNED NOT NULL,
  session_time_id  INT UNSIGNED NOT NULL,
  teacher_id       INT UNSIGNED NOT NULL,
  subject_id       INT UNSIGNED NOT NULL,
  is_active        TINYINT(1) NOT NULL DEFAULT 1,   -- 0 = حصة محذوفة من الجدول لكن لها سجلات سابقة (أرشيف)
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cell_teacher (class_id, day_of_week, session_time_id, teacher_id),
  KEY idx_sched_teacher_day (teacher_id, day_of_week),
  CONSTRAINT fk_sched_class   FOREIGN KEY (class_id)        REFERENCES classes(id)       ON DELETE CASCADE,
  CONSTRAINT fk_sched_time    FOREIGN KEY (session_time_id) REFERENCES session_times(id) ON DELETE RESTRICT,
  CONSTRAINT fk_sched_teacher FOREIGN KEY (teacher_id)      REFERENCES users(id)         ON DELETE CASCADE,
  CONSTRAINT fk_sched_subject FOREIGN KEY (subject_id)      REFERENCES subjects(id)      ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- حضور الأساتذة: التوقيع الرقمي (base64 PNG) + الوقت
-- ---------------------------------------------------------------------
CREATE TABLE teacher_attendance (
  id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  teacher_id              INT UNSIGNED NOT NULL,
  schedule_id             INT UNSIGNED NOT NULL,
  att_date                DATE NOT NULL,
  signature               MEDIUMTEXT NOT NULL,
  signed_at               DATETIME NOT NULL,
  absences_submitted_at   DATETIME NULL,
  ip_address              VARCHAR(45) NULL,
  UNIQUE KEY uq_sched_date (schedule_id, att_date),
  KEY idx_att_date (att_date),
  CONSTRAINT fk_att_teacher  FOREIGN KEY (teacher_id)  REFERENCES users(id)            ON DELETE CASCADE,
  CONSTRAINT fk_att_schedule FOREIGN KEY (schedule_id) REFERENCES classes_schedule(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- غيابات التلاميذ (سطر لكل تلميذ غائب في حصة معينة)
-- is_justified = شُطب اسمه (قدّم رخصة الدخول)
-- ---------------------------------------------------------------------
CREATE TABLE student_absences (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id    INT UNSIGNED NOT NULL,
  schedule_id   INT UNSIGNED NOT NULL,
  absence_date  DATE NOT NULL,
  marked_by     INT UNSIGNED NOT NULL,
  is_justified  TINYINT(1) NOT NULL DEFAULT 0,
  justified_by  INT UNSIGNED NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_absence (student_id, schedule_id, absence_date),
  KEY idx_abs_date (absence_date),
  CONSTRAINT fk_abs_student  FOREIGN KEY (student_id)  REFERENCES students(id)         ON DELETE CASCADE,
  CONSTRAINT fk_abs_schedule FOREIGN KEY (schedule_id) REFERENCES classes_schedule(id) ON DELETE CASCADE,
  CONSTRAINT fk_abs_marker   FOREIGN KEY (marked_by)   REFERENCES users(id)            ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- بيانات أولية
-- =====================================================================

-- حساب المدير:  admin@school.dz  /  Admin@123   (غيّره بعد أول دخول)
INSERT INTO users (full_name, email, password_hash, role, status) VALUES
('المدير', 'admin@school.dz', '$2y$10$76nIhOop9x6riAYEXbz8BOcyG6M3JzDF.QkwKisyojTZRgrV7mbWm', 'admin', 'active');

-- توقيت الحصص كما في ورقة الغياب
INSERT INTO session_times (period, session_no, start_time, end_time) VALUES
('morning', 1, '08:00:00', '09:00:00'),
('morning', 2, '09:00:00', '09:55:00'),
('morning', 3, '10:05:00', '11:00:00'),
('morning', 4, '11:00:00', '12:00:00'),
('evening', 1, '13:30:00', '14:30:00'),
('evening', 2, '14:30:00', '15:25:00'),
('evening', 3, '15:35:00', '16:30:00');

-- المواد الواردة في ورقة الغياب
INSERT INTO subjects (name, short_name) VALUES
('لغة عربية', 'عر'),
('لغة فرنسية', 'فر'),
('لغة انجليزية', 'انج'),
('رياضيات', 'ريا'),
('علوم طبيعية', 'علوم'),
('فيزياء', 'فيزياء'),
('إعلام آلي', 'إعلام'),
('تربية بدنية', 'ت.بدنية'),
('رسم', 'رسم'),
('علوم اجتماعية', 'ع.اجتماعية'),
('تربية اسلامية', 'ت.اسلامية'),
('تربية موسيقية', 'موسيقى');

-- الأقسام الثمانية
INSERT INTO classes (level, group_no, label) VALUES
(1,1,'1م1'),(1,2,'1م2'),(2,1,'2م1'),(2,2,'2م2'),
(3,1,'3م1'),(3,2,'3م2'),(4,1,'4م1'),(4,2,'4م2');
